/*
 * mpu6500.c
 *
 *  Created on: Oct 20, 2019
 *      Author: ASAT
 */
#include <math.h>
#include "mpu6500.h"
#include "main.h"

/*
* Accelerometer Functions
* */
uint8_t registerRead_Accel(uint8_t address, struct MPU6500 sensor){
	address |= 0x80;
	uint8_t msg;
	sensor.gpio_port -> ODR &= ~sensor.gpio_pin;
	HAL_Delay(1);
//	for(int i =0; i<1; i++){}
	HAL_SPI_Transmit(sensor.hspi,&address,1,50);
	HAL_SPI_Receive(sensor.hspi,&msg,1,50);
//	for(int i =0; i<1; i++){}
	HAL_Delay(1);
	sensor.gpio_port -> ODR |= sensor.gpio_pin;
	return msg;
}
void registerWrite_Accel(uint8_t address, uint8_t msg, struct MPU6500 sensor){
	address &= ~0x80;
	sensor.gpio_port -> ODR &= ~sensor.gpio_pin;
	HAL_Delay(1);
	HAL_SPI_Transmit(sensor.hspi,&address,1,50);
	HAL_SPI_Transmit(sensor.hspi,&msg,1,50);
	HAL_Delay(1);
	sensor.gpio_port -> ODR |= sensor.gpio_pin;
}
int16_t read_2_registersAccel(uint8_t address, struct MPU6500 sensor){
	uint16_t acceleration=(uint16_t)registerRead_Accel(address, sensor);
	acceleration=acceleration<<8;
	acceleration|=(uint16_t)registerRead_Accel(address+1, sensor);
	return (int16_t)acceleration;
}
float get_z_accel(struct MPU6500 sensor){
	int16_t reading_z=read_2_registersAccel(accel_zout_msb_address,sensor);
	float retval_z=((float)reading_z*156.8)/32767;	//if you have a different scale for your configuration, change 156.8(16g) to yours (8g or 4g or 2g)
	return retval_z;
}
float get_y_accel(struct MPU6500 sensor){
	int16_t reading_y=read_2_registersAccel(accel_yout_msb_address, sensor);
	float retval_y=((float)reading_y*156.8)/32767;	//if you have a different scale for your configuration, change 156.8(16g) to yours (8g or 4g or 2g)
	return retval_y;
}
float get_x_accel(struct MPU6500 sensor){
	int16_t reading_x=read_2_registersAccel(accel_xout_msb_address, sensor);
	float retval_x=((float)reading_x*156.8)/32767;	//if you have a different scale for your configuration, change 156.8(16g) to yours (8g or 4g or 2g)
	return retval_x;
}
float overall_acceleration(struct MPU6500 sensor){
	float x=get_x_accel(sensor);
	float y=get_y_accel(sensor);
	float z=get_z_accel(sensor);
	float accel_norm=sqrt(x*x+y*y+z*z);
	return accel_norm;
}

/*
* Gyroscope Functions
* */
uint8_t registerRead_Gyro(uint8_t address, struct MPU6500 sensor){
	address |= 0x80;
	uint8_t msg;
	sensor.gpio_port -> ODR &= ~sensor.gpio_pin;
	HAL_Delay(1);
//	for(int i =0; i<1; i++){}
	HAL_SPI_Transmit(sensor.hspi,&address,1,50);
	HAL_SPI_Receive(sensor.hspi,&msg,1,50);
//	for(int i =0; i<1; i++){}
	HAL_Delay(1);
	sensor.gpio_port -> ODR |= sensor.gpio_pin;
	return msg;
}
void registerWrite_Gyro(uint8_t address, uint8_t msg, struct MPU6500 sensor){
	address &= ~0x80;
	sensor.gpio_port -> ODR &= ~sensor.gpio_pin;
	HAL_Delay(1);
	HAL_SPI_Transmit(sensor.hspi,&address,1,50);
	HAL_SPI_Transmit(sensor.hspi,&msg,1,50);
	HAL_Delay(1);
	sensor.gpio_port -> ODR |= sensor.gpio_pin;
}
int16_t read_2_registersGyro(uint8_t address, struct MPU6500 sensor){
	uint16_t rotation=(uint16_t)registerRead_Accel(address, sensor);
	rotation=rotation<<8;
	rotation|=(uint16_t)registerRead_Gyro(address+1, sensor);
	return (int16_t)rotation;
}
float get_z_rotation(struct MPU6500 sensor){
	int16_t reading_z=read_2_registersGyro(gyro_zout_msb_address,sensor);
	float retval_z=((float)reading_z*2000)/32767;	//if you have a different scale for your configuration, change the 2000 to yours (1000 or 500 or 250)
	return retval_z;
}
float get_y_rotation(struct MPU6500 sensor){
	int16_t reading_y=read_2_registersGyro(gyro_yout_msb_address, sensor);
	float retval_y=((float)reading_y*2000)/32767;	//if you have a different scale for your configuration, change the 2000 to yours (1000 or 500 or 250)
	return retval_y;
}
float get_x_rotation(struct MPU6500 sensor){
	int16_t reading_x=read_2_registersGyro(gyro_xout_msb_address, sensor);
	float retval_x=((float)reading_x*2000)/32767;	//if you have a different scale for your configuration, change the 2000 to yours (1000 or 500 or 250)
	return retval_x;
}

void mpu6500_sensor_Init(struct MPU6500 *sensor, SPI_HandleTypeDef *hspi, GPIO_TypeDef *port, uint16_t pin){
	

	sensor->hspi = hspi;
	sensor->gpio_port = port;
	sensor->gpio_pin = pin;
	
	short temp = FIFO_MODE | EXT_SYNC_SET | DLPF_CFG;
	registerWrite_Accel(config_address, temp, *sensor);	//
	registerWrite_Accel(accel_config2_address, accel_config2_value, *sensor);	//
	temp = 0;
	temp = XA_ST | YA_ST | ZA_ST | ACCEL_FS_SEL;
	registerWrite_Accel(accel_config_address, temp, *sensor);	//max 16g
	temp = 0;
	temp = XG_ST | YG_ST | ZG_ST | GYRO_FS_SEL;               // for gyroscope
	registerWrite_Gyro(gyro_config_address, temp, *sensor);	//2000dps
}
