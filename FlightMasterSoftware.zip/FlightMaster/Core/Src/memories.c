/*
 * memories.c
 *
 *  Created on: 26 Ιουλ 2023
 *      Author: Vaggelis
 */

#include "string.h"
#include "fatfs.h"
#include "math.h"
#include "SD_Functions.h"
#include "fatfs_sd.h"
#include <stdio.h>
#include "main.h"
#include "memories.h"
#include "fatfs_sd.h"
#include "flash.h"



//FLASH_FUNCTIONS
int flash_free_space_check(){
	  /*********************************FLASH CHECK********************************/
	   /* This function checks if there are any data written in the 0 address or the gps data address of the flash memory
	   * if there is NOT enough space in flash to write data for an entire flight it returns 0
	   * if there are is enough space it returns 1 and saves the right address to write to*/

	  	int end_counter=0;
	  	struct dataflash_sensors flashDataReadSensors;
	  	uint8_t *pointer;
	  	uint8_t store_address[3];
	  	pointer = (uint8_t*) &flashDataReadSensors;
	  	int check_data=0;

/************************************************** check if any sensors data are written************************************/
	  	while ((end_counter < NUMBER_OF_GARBAGE) && (flash_address_sensors < GPS_DATA_START_ADDRESS-sizeof(struct dataflash_sensors))) {

	 		store_address[2] = flash_address_sensors;
	  		store_address[1] = flash_address_sensors>> 8;
	  		store_address[0] = flash_address_sensors >> 16;

	  		while (getBusy(hspi1) == 1) {

	  		}

	  		readData(hspi1, store_address, sizeof(struct dataflash_sensors), pointer);


	  		if (flashDataReadSensors.time != UINT32_MAX) {
	  			end_counter = 0;
	  		}
	  		if (flashDataReadSensors.time == UINT32_MAX) {
	  			end_counter++;
	  		}

	  		flash_address_sensors += sizeof(struct dataflash_sensors);

	  		uint32_t mask = 0x000000FF;
	  		if ((flash_address_sensors & mask) > ((flash_address_sensors + sizeof(struct dataflash_sensors)) & mask)) {
	  			flash_address_sensors += sizeof(struct dataflash_sensors);
	  		}

	  	}

	  		 //if there is not enough space to write sensors data for a flight
	  		 if(flash_address_sensors > GPS_DATA_START_ADDRESS - NUMBER_OF_SPACE){
		  		 check_data = 1;
	  		 }



/************************************************** check if any gps data are written************************************/

	    int page_shifts_counter = 0 ;
	  	end_counter = 0;
	  	struct dataflash_sensors flashDataReadGps;
	  	pointer = (uint8_t*) &flashDataReadGps;

		  	while ((end_counter < NUMBER_OF_GARBAGE) && (flash_address_gps < FLASH_TOTAL_SPACE -sizeof(struct dataflash_gps))) {

		 		store_address[2] = flash_address_gps;
		  		store_address[1] = flash_address_gps>> 8;
		  		store_address[0] = flash_address_gps >> 16;

		  		while (getBusy(hspi1) == 1) {

		  		}

		  		readData(hspi1, store_address, sizeof(struct dataflash_gps), pointer);


		  		if (flashDataReadGps.time != UINT32_MAX) {
		  			end_counter = 0;
		  		}
		  		if (flashDataReadGps.time == UINT32_MAX) {
		  			end_counter++;
		  		}

		  		flash_address_gps += sizeof(struct dataflash_gps);

		  		uint32_t mask = 0x000000FF;
		  		if ((flash_address_gps & mask) > ((flash_address_gps + sizeof(struct dataflash_gps)) & mask)) {
		  			flash_address_gps += sizeof(struct dataflash_gps);
		  			page_shifts_counter++;
		  		}

		  	}

		  		 if(flash_address_gps > GPS_DATA_START_ADDRESS + 3* NUMBER_OF_SPACE){
			  		 check_data = 1;
		  		 }


		  	 if(check_data == 1){
		  		 return 0;
		  	 }

		  	 //remove the free space that you checked to make sure there are no more data in the memory
	  		flash_address_sensors = flash_address_sensors - NUMBER_OF_GARBAGE * sizeof(struct dataflash_sensors) ;
	  		flash_address_gps = flash_address_gps - NUMBER_OF_GARBAGE * sizeof(struct dataflash_gps)
	  							- page_shifts_counter *sizeof(struct dataflash_gps) ;

	  		return 1;

}
void flash_clear(){
	/*this function clears all data in the flash memory*/
	while (getBusy(hspi1) == 1) {

		}

		chipErase(hspi1);

		while (getBusy(hspi1) == 1) {
		    //toggle red led
			LED_RED_GPIO_Port->ODR |= LED_RED_Pin;
			HAL_Delay(500);
			LED_RED_GPIO_Port->ODR &= ~LED_RED_Pin;
			HAL_Delay(500);
		}


}

//FOR BOTH MEMORIES
void write_data_sensors(struct datasd_sensors datasd_sensors){
	/* this functon takes data saved in the datasd_sensors struct
	 *  and writes them both in sd and flash memories */

	if ((flash_address_sensors + sizeof(struct dataflash_sensors)) < (GPS_DATA_START_ADDRESS - 4)) {

			uint8_t store_address[3] = { 0, 0, 0 };       //address to write in flash

			store_address[2] = flash_address_sensors;
			store_address[1] = flash_address_sensors >> 8;
			store_address[0] = flash_address_sensors >> 16;

			if(datasd_sensors.height>5000){
				datasd_sensors.height = 5000;
			}


			struct dataflash_sensors dataflash_sensors;                //convert to dataflash_sensors struct
			dataflash_sensors.height = convert_data_for_flash(datasd_sensors.height, 10);
			dataflash_sensors.time = (uint32_t) (datasd_sensors.time);
			dataflash_sensors.velocity = convert_data_for_flash(datasd_sensors.velocity, 10);
			dataflash_sensors.x_acceleration = convert_data_for_flash(datasd_sensors.x_acceleration, 100);
			dataflash_sensors.x_rotation = convert_data_for_flash(datasd_sensors.x_rotation, 10);
			dataflash_sensors.y_acceleration = convert_data_for_flash(datasd_sensors.y_acceleration, 100);
			dataflash_sensors.y_rotation = convert_data_for_flash(datasd_sensors.y_rotation, 10);
			dataflash_sensors.z_acceleration = convert_data_for_flash(datasd_sensors.z_acceleration, 100);
			dataflash_sensors.z_rotation = convert_data_for_flash(datasd_sensors.z_rotation, 10);

			struct dataflash_sensors *dataPointer;
			dataPointer = &dataflash_sensors;
			uint8_t *uint8_tPointer;
			uint8_tPointer = (uint8_t*) dataPointer;

			while (getBusy(hspi1) == 1) {

			}

			pageProgram(hspi1, uint8_tPointer, sizeof(struct dataflash_sensors),store_address);  //write flash
			flash_address_sensors += sizeof(struct dataflash_sensors);

		    uint32_t mask = 0x000000FF;
		    if((flash_address_sensors & mask) > ((flash_address_sensors+sizeof(struct dataflash_sensors))& mask)){
		    	flash_address_sensors += sizeof(struct dataflash_sensors);
		    }

		}
		datasd_sensors.time=datasd_sensors.time/1000;

		sd_write_data_sensors(datasd_sensors,"sensors data.txt");
}
void write_data_gps(struct datasd_gps datasd_gps){
	/* this functon takes data saved in the datasd_gps struct
	 *  and writes them both in sd and flash memories */
	if ((flash_address_gps + sizeof(struct dataflash_gps)) < (FLASH_TOTAL_SPACE - 4)) {

				uint8_t store_address[3] = { 0, 0, 0 };       //address to write in flash

				store_address[2] = flash_address_gps;
				store_address[1] = flash_address_gps >> 8;
				store_address[0] = flash_address_gps >> 16;

				if(datasd_gps.altitude>5000){
					datasd_gps.altitude = 5000;
				}

				if(datasd_gps.sea_level>5000){
					datasd_gps.sea_level = 5000;
				}


				struct dataflash_gps dataflash_gps;                //convert to dataflash_gps struct
				dataflash_gps.current_time_UTC = (uint32_t)datasd_gps.current_time_UTC;
				dataflash_gps.flight_time = (uint32_t) (datasd_gps.flight_time);
				dataflash_gps.lat = (uint32_t)(datasd_gps.lat*1000000);
				dataflash_gps.lon = (uint32_t)(datasd_gps.lon*1000000);
				dataflash_gps.satellites = (uint8_t)(datasd_gps.satellites);
				dataflash_gps.HDOP = convert_data_for_flash(datasd_gps.HDOP, 10);
				dataflash_gps.altitude = convert_data_for_flash(datasd_gps.altitude, 10);
				dataflash_gps.sea_level = convert_data_for_flash(datasd_gps.sea_level, 10);


				struct dataflash_gps *dataPointer;
				dataPointer = &dataflash_gps;
				uint8_t *uint8_tPointer;
				uint8_tPointer = (uint8_t*) dataPointer;

				while (getBusy(hspi1) == 1) {

				}

				pageProgram(hspi1, uint8_tPointer, sizeof(struct dataflash_gps),store_address);  //write flash
				flash_address_gps += sizeof(struct dataflash_gps);

			    uint32_t mask = 0x000000FF;
			    if((flash_address_gps & mask) > ((flash_address_gps+ sizeof(struct dataflash_gps))& mask)){
			    	flash_address_gps += sizeof(struct dataflash_gps);
			    }

			}
			datasd_gps.flight_time=datasd_gps.flight_time/1000;

			sd_write_data_gps(datasd_gps,"gps data.txt");

}
void flash_read_and_write_to_sd_sensors(char filename[]){
	/*this function takes data written in the 0 address of the flash memory ( that is sensors data)
	 * then writes them in sd using the argument filename[] as a name for an sd .txt
	 */
	sd_create_text_sensors(filename);

	flash_address_sensors = 0;
	struct dataflash_sensors flashDataRead;
	uint8_t *pointer;
	pointer = (uint8_t*) &flashDataRead;
	int end_counter;
	int flash_read_end;

	flash_read_end=0;
	flashDataRead.height=0;

	while (flash_read_end == 0) {


    	if((HAL_GetTick()/1000)%2 == 0){   //Toggle Green Led
    		LED_GREEN_GPIO_Port->ODR |= LED_GREEN_Pin;
    	}
    	if((HAL_GetTick()/1000)%2 == 1){
    		LED_GREEN_GPIO_Port->ODR &= ~LED_GREEN_Pin;
    	}

		//transfer data from the flash to the sd
		uint8_t store_address[3];
		store_address[2] = flash_address_sensors;
		store_address[1] = flash_address_sensors >> 8;
		store_address[0] = flash_address_sensors >> 16;

		while (getBusy(hspi1) == 1) {

		}

		readData(hspi1, store_address, sizeof(struct dataflash_sensors), pointer);


		//convert dataflash_sensors struct to datasd_sensors struct
		struct datasd_sensors dataForSD;

		dataForSD.height =  flashDataRead.height;
		if (dataForSD.height > 50000) {                     //HEIGHT
			dataForSD.height -= 65536;
		}
		dataForSD.height /= 10;

		dataForSD.time = (float) flashDataRead.time /1000;        //TIME
		dataForSD.velocity = convert_data_for_sd(flashDataRead.velocity,10);
		dataForSD.x_acceleration = convert_data_for_sd(flashDataRead.x_acceleration,100);
		dataForSD.x_rotation = convert_data_for_sd(flashDataRead.x_rotation,10);
		dataForSD.y_acceleration = convert_data_for_sd(flashDataRead.y_acceleration,100);
		dataForSD.y_rotation = convert_data_for_sd(flashDataRead.y_rotation,10);
		dataForSD.z_acceleration = convert_data_for_sd(flashDataRead.z_acceleration,100);
		dataForSD.z_rotation =convert_data_for_sd(flashDataRead.z_rotation,10);



		if(flashDataRead.time != UINT32_MAX){
			sd_write_data_sensors(dataForSD,filename);
			end_counter = 0;
		}
		if( flashDataRead.time == UINT32_MAX){
			end_counter++;
		}

		if((end_counter > NUMBER_OF_GARBAGE) || flash_address_sensors >= GPS_DATA_START_ADDRESS ){
			flash_read_end=1;

		}

		flash_address_sensors += sizeof(struct dataflash_sensors);

	    uint32_t mask = 0x000000FF;
	    if((flash_address_sensors & mask) > ((flash_address_sensors+sizeof(struct dataflash_sensors))& mask)){
	        flash_address_sensors += sizeof(struct dataflash_sensors);
	    }

	}




}
void flash_read_and_write_to_sd_gps(char filename[]){
	/*this function takes data written in the gps_data_start_address of the flash memory ( that is gps data)
	 * then writes them in sd using the argument filename[] as a name for an sd .txt
	 */

	    sd_create_text_gps(filename);

		flash_address_gps = GPS_DATA_START_ADDRESS;
		struct dataflash_gps flashDataRead;
		uint8_t *pointer;
		pointer = (uint8_t*) &flashDataRead;
		int end_counter=0;
		int flash_read_end;

		flash_read_end=0;
		flashDataRead.altitude = 0;
		flashDataRead.sea_level = 0;

		while (flash_read_end == 0) {



	    	if((HAL_GetTick()/1000)%2 == 0){   //Toggle Green Led
	    		LED_GREEN_GPIO_Port->ODR |= LED_GREEN_Pin;
	    	}
	    	if((HAL_GetTick()/1000)%2 == 1){
	    		LED_GREEN_GPIO_Port->ODR &= ~LED_GREEN_Pin;
	    	}

			//transfer data from the flash to the sd
			uint8_t store_address[3];
			store_address[2] = flash_address_gps;
			store_address[1] = flash_address_gps >> 8;
			store_address[0] = flash_address_gps >> 16;

			while (getBusy(hspi1) == 1) {

			}

			readData(hspi1, store_address, sizeof(struct dataflash_gps), pointer);


			//convert dataflash_gps struct to datasd_gps struct
			struct datasd_gps dataForSD;

			dataForSD.altitude =  flashDataRead.altitude;
			dataForSD.sea_level = flashDataRead.sea_level;

			if (dataForSD.altitude > 50000) {                     //HEIGHT
				dataForSD.altitude -= 65536;
			}

			if(dataForSD.sea_level > 50000){
				dataForSD.sea_level -= 65536;
			}

			dataForSD.altitude /= 10;
			dataForSD.sea_level /= 10;

			dataForSD.flight_time = (float) flashDataRead.flight_time /1000;
			dataForSD.current_time_UTC = (float) flashDataRead.current_time_UTC;
			dataForSD.lat = (float)flashDataRead.lat/1000000;
			dataForSD.lon = (float)flashDataRead.lon/1000000;
			dataForSD.HDOP = convert_data_for_sd(flashDataRead.HDOP, 10);
			dataForSD.satellites= (float)flashDataRead.satellites;



	//		if(flashDataRead.time == 6969690){ // change that
	//			sd_update_text("\n\n\n\n\nNEW FLIGHT\n\n\n\n\n", "flash.txt");
	//			sd_create_text("flash.txt");
	//		}

			if(flashDataRead.flight_time != UINT32_MAX){
				sd_write_data_gps(dataForSD,filename);
				end_counter = 0;
			}
			if( flashDataRead.flight_time == UINT32_MAX){
				end_counter++;
			}

			if((end_counter > NUMBER_OF_GARBAGE) || flash_address_gps >= FLASH_TOTAL_SPACE ){
				flash_read_end=1;

			}

			flash_address_gps += sizeof(struct dataflash_gps);

		    uint32_t mask = 0x000000FF;
		    if((flash_address_gps & mask) > ((flash_address_gps+sizeof(struct dataflash_gps))& mask)){
		        flash_address_gps += sizeof(struct dataflash_gps);
		    }

		}

}


uint16_t convert_data_for_flash(float data , int multiplication_factor){
	if(data>=0){
		return (uint16_t)(data*multiplication_factor);
	}
	else {
		return (uint16_t)(UINT16_MAX+data*multiplication_factor);
	}
}
float convert_data_for_sd(uint16_t data , int division_factor){

	float result;

	if(data>(UINT16_MAX/2)){
		result = (float)(data-UINT16_MAX)/division_factor;
		return result;
	}
	else{
		result = (float)data/division_factor;
		return result;
	}

}
