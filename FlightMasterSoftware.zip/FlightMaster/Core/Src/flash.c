/*
 * flash.c
 *
 *  Created on: May 22, 2023
 *      Author: Vaggelis
 */
#include "main.h"

void writeEnable(SPI_HandleTypeDef hspi1){
	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	uint8_t msg = 0x06;

	HAL_SPI_Transmit(&hspi1,&msg,1,150);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
}

void writeDisable(SPI_HandleTypeDef hspi1){
	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	uint8_t msg = 0x04;

	HAL_SPI_Transmit(&hspi1,&msg,1,50);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
}

void sectorErase(SPI_HandleTypeDef hspi1, uint8_t *address){
	writeEnable (hspi1);
	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	uint8_t instruction=0x20;
	HAL_SPI_Transmit(&hspi1,&instruction,1,50);
	HAL_SPI_Transmit(&hspi1,address,3,50);


	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
}

uint8_t readStatusRegister1(SPI_HandleTypeDef hspi1){
	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	uint8_t send[1]={0x05};
	HAL_SPI_Transmit(&hspi1,send,1,50);

	uint8_t recieve[1];
	HAL_SPI_Receive(&hspi1,recieve,1,50);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
	return recieve[0];
}

uint8_t readStatusRegister2(SPI_HandleTypeDef hspi1){
	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	uint8_t send[1]={0x35};
	HAL_SPI_Transmit(&hspi1,send,1,50);

	uint8_t recieve[1];
	HAL_SPI_Receive(&hspi1,recieve,1,50);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
	return recieve[0];
}

uint8_t readStatusRegister3(SPI_HandleTypeDef hspi1){
	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	uint8_t send[1]={0x15};
	HAL_SPI_Transmit(&hspi1,send,1,50);

	uint8_t recieve[1];
	HAL_SPI_Receive(&hspi1,recieve,1,50);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
	return recieve[0];
}


uint8_t getBusy(SPI_HandleTypeDef hspi1){
	return (readStatusRegister1(hspi1) & 0B00000001);
}

void pageProgram(SPI_HandleTypeDef hspi1,uint8_t *writeData, uint16_t size, uint8_t *address){

	writeEnable(hspi1);

	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	//send instruction
	uint8_t send[1]={0x02};
	HAL_SPI_Transmit(&hspi1,send,1,150);


	//send address
	HAL_SPI_Transmit(&hspi1,address,3,50);

	//send data
	HAL_SPI_Transmit(&hspi1,writeData,size,10*size);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
}

void chipErase(SPI_HandleTypeDef hspi1){
	writeEnable(hspi1);

	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	//send instruction
	uint8_t send[1]={0x60};
	HAL_SPI_Transmit(&hspi1,send,1,50);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
}

void readData(SPI_HandleTypeDef hspi1, uint8_t *address,uint16_t size,uint8_t *read){
	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	uint8_t send[1]={0x03};
	HAL_SPI_Transmit(&hspi1,send,1,50);

	//send address
	HAL_SPI_Transmit(&hspi1,address,3,50);


	HAL_SPI_Receive(&hspi1,read,size,50);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH
}

uint8_t readID(SPI_HandleTypeDef hspi1){
	flash_CS_GPIO_Port -> ODR &= ~flash_CS_Pin;     //CS LOW

	uint8_t send[1]={0x90};
	HAL_SPI_Transmit(&hspi1,send,1,50);

	uint8_t zero[3]={0x00,0x00,0x00};
	HAL_SPI_Transmit(&hspi1,zero,3,50);

	uint8_t read=0;
	HAL_SPI_Receive(&hspi1,&read,1,50);

	flash_CS_GPIO_Port -> ODR |= flash_CS_Pin;     //CS HIGH

	return read;


}




