/* USER CODE BEGIN Header */


/* 		FlightMaster flight computer
 * 				by Vaggelis Sourlas
 */


/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/***********************************************INCLUDE_LIBRARIES_BEGIN**********************************/

#include <math.h>
#include <stdlib.h>
#include "stdio.h"
#include <time.h>
#include "BMP280.h"
#include "mpu6500.h"
#include "string.h"
#include "SD_Functions.h"
#include "fatfs_sd.h"
#include "flash.h"
#include "memories.h"


/***********************************************INCLUDE_LIBRARIES_END*************************************/
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/***********************************************DEFINES_BEGIN*******************************************/

#define MAIN_DEPLOY_HEIGHT 450//in m
#define INIT_ACC 30 //in m/s^2
#define THRUST_END_ACC 50//in m/s^2
#define APOGGE_DETECT_VELOCITY 5 //in m/s
#define OPEN_SWITCH_TIME 3000 //in ms
#define SIMULATION_START_TIME 12000
#define BUZZER_REPEAT 5
#define FLIGHT_END_COUNTER 3
#define NUMBER_OF_MEASUREMENTS 12
#define NUMBER_OF_SUCCESSFUL_MEASUREMENTS 10
#define MIN_TIME_PASSED_FOR_APOGEE_DETECT 15000

/***********************************************DEFINES_END*********************************************/
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi3;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim7;
TIM_HandleTypeDef htim16;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
/***********************************************VARIABLES_BEGIN*********************************************/
//SENSORS VARIABLES
struct MPU6500 accelerometer;
struct bmp280_dev bmp;
float initial_altitude,apogee ;

//COMMS VARIABLES
UART_HandleTypeDef *lora_huart = &huart2;
TIM_HandleTypeDef *lora_rx_htim = &htim7;
TIM_HandleTypeDef *lora_tx_htim = &htim6;
uint8_t LoRa_receiveByte;
uint8_t LoRa_RxBuffer[30];
uint16_t LoRa_RxCounter=0;
int buffer_erase = 0;


//GPS VARIABLES
TIM_HandleTypeDef *gps_htim = &htim16;
UART_HandleTypeDef *gps_huart = &huart3;
uint8_t GPS_receiveByte;
uint8_t GPS_RxBuffer[2][100];
uint8_t GPS_BufferCounter=0;
uint16_t GPS_RxCounter=0;
uint8_t GPS_messageReady=0;
int first_gps_signal = 0;

//SD VARIABLES
uint32_t SD_free_space;
struct datasd_sensors datasd_sensors;
struct datasd_gps datasd_gps;
int create_files = 0;

//FLASH VARIABLES
int switch1,switch2;

//FLIGHT VARIABLES
int drogue_continuity=0;
int main_continuity=0;
float acceleration_array[NUMBER_OF_MEASUREMENTS],altitude_array[NUMBER_OF_MEASUREMENTS]
			,time_array[NUMBER_OF_MEASUREMENTS],velocity_array[NUMBER_OF_MEASUREMENTS];
int activate_command ,start,thrust_end,drogue_parachute,main_parachute,flight_end; //flags
float flight_start_time, thrust_end_time, apogee_time, drogue_deploy_time, main_deploy_time, flight_end_time; //time stamps
int counter_thrust, counter_apogee, counter_main_parachute, counter_end , counter_end2; //counters
float initial_altitude,apogee;
uint32_t temp_time;
int lora_bool=0;
int i, j;

//SIMULATION VARIABLES
int simulation = 0;
int simulation_time=0;
int test_sensors = 0;


//DEBUG VARIABLES
uint32_t time1,time2,loop_time;
int flight_start_led=0;

/***********************************************VARIABLES_END***********************************************/
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI3_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM16_Init(void);
static void MX_TIM7_Init(void);
static void MX_TIM6_Init(void);
/* USER CODE BEGIN PFP */
/***********************************************FUNCTION_PROTOTYPES_BEGIN********************************/

//BMP280_FUNCTIONS
void delay_ms(uint32_t period_ms);
int8_t spi_reg_write(uint8_t cs, uint8_t reg_addr, uint8_t *reg_data, uint16_t length);
int8_t spi_reg_read(uint8_t cs, uint8_t reg_addr, uint8_t *reg_data, uint16_t length);
float get_altitude();
void BMP280_setup();

//SIMULATION_FUNCTIONS
float simulate_acceleration();
float simulate_altitude();
void get_simulation_measurements();

//GPS FUNCTIONS
float charToFloat(uint8_t c);
void checkGPSMessage();

//GENERAL_PURPOSE_FUNCTIONS
void get_sensors_measurements();
void lora_send_sensors();
void lora_send_gps();
void lora_set_parameters();
void flight_checks();
void check_switches();
void check_igniters_continuity();
int check_location_command();
int check_activate_sensors_command();
int check_reset_command();
int check_test_command();
int check_simulation_command();
int check_apogee_command();
/***********************************************FUNCTION_PROTOTYPES_END********************************/
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/***********************************************USER_CODE_0_BEGIN********************************/


/***********************************************USER_CODE_0_END********************************/
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI3_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  MX_SPI1_Init();
  MX_FATFS_Init();
  MX_TIM2_Init();
  MX_TIM16_Init();
  MX_TIM7_Init();
  MX_TIM6_Init();
  /* USER CODE BEGIN 2 */
  /***********************************************MAIN_BEGIN*********************************************/

//  //Initialiaze GPIO Ports  (set all CS -> 1 and pyrochannels -> 0 )
  HAL_GPIO_WritePin(CS_ACCEL_GPIO_Port, CS_ACCEL_Pin, 1);
  HAL_GPIO_WritePin(CS_BAR_GPIO_Port, CS_BAR_Pin, 1);
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin,1);
  HAL_GPIO_WritePin(FLASH_HOLD_GPIO_Port,FLASH_HOLD_Pin,1);
  HAL_GPIO_WritePin(flash_CS_GPIO_Port, flash_CS_Pin, 1);
  HAL_GPIO_WritePin(GPS_SWITCH_GPIO_Port, GPS_SWITCH_Pin, 1);
  HAL_GPIO_WritePin(RF_SWITCH_GPIO_Port, RF_SWITCH_Pin, 0);


  HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, 0);
  HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 0);
  HAL_GPIO_WritePin(DROGUE_GPIO_Port,DROGUE_Pin,0);
  HAL_GPIO_WritePin(MAIN_GPIO_Port,MAIN_Pin,0);
  HAL_GPIO_WritePin(DROGUE_CHECK_GPIO_Port, DROGUE_CHECK_Pin,0);
  HAL_GPIO_WritePin(MAIN_CHECK_GPIO_Port, MAIN_CHECK_Pin,0);

  //Turn on and off the timer because it doesn't work properly the first time
  HAL_TIM_Base_Start_IT(gps_htim);
  HAL_TIM_Base_Start_IT(lora_rx_htim);
  HAL_TIM_Base_Start_IT(lora_tx_htim);

  HAL_TIM_Base_Stop_IT(gps_htim);
  HAL_TIM_Base_Stop_IT(lora_rx_htim);
  HAL_TIM_Base_Stop_IT(lora_tx_htim);

  //start the gps receive interrupt (first thing to be done because if you delay it apparently the GPS decides to stop working)
  HAL_UART_Receive_IT(gps_huart, &GPS_receiveByte, 1);
  HAL_UART_Receive_IT(lora_huart, &LoRa_receiveByte, 1);

  /************************************************GPIO PORTS END*********************************************/
  //Initialize Sensors (SPI 3)
  mpu6500_sensor_Init(&accelerometer, &hspi3, CS_ACCEL_GPIO_Port, CS_ACCEL_Pin);
  HAL_Delay(500);
  BMP280_setup();
  initial_altitude = get_altitude(); /*Get initial altitude as a reference point*/

  /*********************************************SENSORS END***************************************************/

  //Initizalize memories (SPI 1)
  /* SD needs to be set at FAT32 and 32kbytes  */
  fres = f_mount(&fs, "", 0);
  HAL_Delay(500);

  //set the correct adresses to write data in flash
  flash_address_sensors = 0;
  flash_address_gps = GPS_DATA_START_ADDRESS;

  /*********************************************MEMORIES END*********************************************************/
  //read SWITCH1 and SWITCH2 pins
  switch1 = HAL_GPIO_ReadPin(SWITCH_1_GPIO_Port, SWITCH_1_Pin);
  switch2 = HAL_GPIO_ReadPin(SWITCH_2_GPIO_Port, SWITCH_2_Pin);

  //check_switches();

  /*************************************************SWITCHES CHECK END**************************************/

  check_igniters_continuity();

  /******************************************CONINUITY END**************************************************/

  //make all necessary variables equal to zero
  activate_command = start = thrust_end = drogue_parachute = main_parachute = flight_end = counter_end2 = counter_end = 0;
  flight_start_time = thrust_end_time = apogee_time = drogue_deploy_time = main_deploy_time = flight_end_time = 0;
  for(j=0;j<NUMBER_OF_MEASUREMENTS;j++){
	  acceleration_array[j]= altitude_array[j]= velocity_array[j] = time_array[j] = 0;
  }
  apogee =0;

  srand(time(NULL));


  /***********************************************MAIN_END***********************************************/
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  /*******************************************LOOP_BEGIN*******************************************/

//	  // test recovery systems
//	  for(int i=0;i<10;i++){
//		  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
//		  HAL_Delay(500);
//		  HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
//		  HAL_Delay(500);
//	  }
//
//
//	  HAL_GPIO_WritePin(MAIN_GPIO_Port,MAIN_Pin,1);
//	  HAL_Delay(3000);
//	  HAL_GPIO_WritePin(MAIN_GPIO_Port,MAIN_Pin,0);
//
//	  HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, 1);
//
//
//	  while(1){
//
//	  }

//	  // test gps
//	  if(GPS_messageReady==1){
//		  checkGPSMessage();
//	  }

    //test sensors
	  datasd_sensors.height = get_altitude()-initial_altitude;
	  datasd_sensors.x_acceleration = get_x_accel(accelerometer);
	  datasd_sensors.x_rotation = get_x_rotation(accelerometer);
	  datasd_sensors.y_acceleration = get_y_accel(accelerometer);
	  datasd_sensors.y_rotation = get_y_rotation(accelerometer);
	  datasd_sensors.z_acceleration = get_z_accel(accelerometer);
	  datasd_sensors.z_rotation = get_z_rotation(accelerometer);
	  HAL_Delay(100);

//      //test memories
//	  for (int j = 0;j<10;j++){
//
//		  datasd_gps.HDOP = 10.2;
//		  datasd_gps.altitude = 5001.69;
//		  datasd_gps.current_time_UTC = 174245;
//		  datasd_gps.flight_time= 15430;
//		  datasd_gps.lat = 40.698784;
//		  datasd_gps.lon = 20.956563;
//		  datasd_gps.satellites = 18;
//		  datasd_gps.sea_level = -15.3;
//
//		  datasd_sensors.height = 50.3;
//		  datasd_sensors.x_acceleration = get_x_accel(accelerometer);
//		  datasd_sensors.x_rotation = get_x_rotation(accelerometer);
//		  datasd_sensors.y_acceleration = get_y_accel(accelerometer);
//		  datasd_sensors.y_rotation = get_y_rotation(accelerometer);
//		  datasd_sensors.z_acceleration = get_z_accel(accelerometer);
//		  datasd_sensors.z_rotation = get_z_rotation(accelerometer);
//
//		  write_data_gps(datasd_gps);
//		  write_data_sensors(datasd_sensors);
//	  }
//
//  	  while(1){
//
//  	}

//    //test time
//	  time2 = HAL_GetTick();
//	  loop_time=time2-time1;
//	  time1= HAL_GetTick();


/******************************************************FLIGHT CODE BEGIN********************************************/

	  if(GPS_messageReady==1){
		  checkGPSMessage();
	  }

    /**************************************when you have received the activation command******************************************/
		if ( activate_command == 1 && flight_end==0  ) {
			get_sensors_measurements();

			if(start == 0){


				//if at least one acceleration value is above the limit start transmitting data
				if(acceleration_array[i]> INIT_ACC ){
					start = 1;
					flight_start_time = HAL_GetTick();
					datasd_sensors.time = 0;
					datasd_sensors.height = 0;
					datasd_sensors.velocity = 0;
					initial_altitude = altitude_array[i] + initial_altitude;
					lora_send_sensors();
					HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 1);
					HAL_TIM_Base_Start_IT(lora_tx_htim);
				}
			}

			if((HAL_GetTick() - flight_start_time > 1000) && flight_start_led == 0 && start == 1){
				HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 0);
				flight_start_led = 1;
			}


			if(start == 1 && flight_end == 0){
				write_data_sensors(datasd_sensors);
				flight_checks();
			}

		 	i++;
		 	if (i == NUMBER_OF_MEASUREMENTS ) {//dont go out of arrays borders
		 		i = 0;
		 	}
		}

/******************************************************FLIGHT CODE END********************************************/
  } //while bracket

  /***********************************************LOOP_END*********************************************/
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 36;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief SPI3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI3_Init(void)
{

  /* USER CODE BEGIN SPI3_Init 0 */

  /* USER CODE END SPI3_Init 0 */

  /* USER CODE BEGIN SPI3_Init 1 */

  /* USER CODE END SPI3_Init 1 */
  /* SPI3 parameter configuration*/
  hspi3.Instance = SPI3;
  hspi3.Init.Mode = SPI_MODE_MASTER;
  hspi3.Init.Direction = SPI_DIRECTION_2LINES;
  hspi3.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi3.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi3.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi3.Init.NSS = SPI_NSS_SOFT;
  hspi3.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi3.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi3.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi3.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi3.Init.CRCPolynomial = 7;
  hspi3.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi3.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI3_Init 2 */

  /* USER CODE END SPI3_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 71;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 660;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 66;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 7200-1;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 2000-1;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief TIM7 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM7_Init(void)
{

  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */
  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 48000;
  htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 300;
  htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM7_Init 2 */

  /* USER CODE END TIM7_Init 2 */

}

/**
  * @brief TIM16 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM16_Init(void)
{

  /* USER CODE BEGIN TIM16_Init 0 */

  /* USER CODE END TIM16_Init 0 */

  /* USER CODE BEGIN TIM16_Init 1 */

  /* USER CODE END TIM16_Init 1 */
  htim16.Instance = TIM16;
  htim16.Init.Prescaler = 48000;
  htim16.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim16.Init.Period = 300;
  htim16.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim16.Init.RepetitionCounter = 0;
  htim16.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim16) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM16_Init 2 */

  /* USER CODE END TIM16_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, DROGUE_CHECK_Pin|DROGUE_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOH, MAIN_Pin|MAIN_CHECK_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, SD_CS_Pin|FLASH_HOLD_Pin|flash_CS_Pin|CS_BAR_Pin
                          |LED_RED_Pin|LED_GREEN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, FLASH_WP_Pin|RF_SEL_Pin|RF_SWITCH_Pin|GPS_SWITCH_Pin
                          |CS_ACCEL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : DROGUE_CHECK_Pin DROGUE_Pin */
  GPIO_InitStruct.Pin = DROGUE_CHECK_Pin|DROGUE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : DROGUE_CONTINUITY_Pin */
  GPIO_InitStruct.Pin = DROGUE_CONTINUITY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(DROGUE_CONTINUITY_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : MAIN_Pin MAIN_CHECK_Pin */
  GPIO_InitStruct.Pin = MAIN_Pin|MAIN_CHECK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

  /*Configure GPIO pins : MAIN_CONTINUITY_Pin RF_IRQ_Pin */
  GPIO_InitStruct.Pin = MAIN_CONTINUITY_Pin|RF_IRQ_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : SWITCH_2_Pin */
  GPIO_InitStruct.Pin = SWITCH_2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(SWITCH_2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SWITCH_1_Pin */
  GPIO_InitStruct.Pin = SWITCH_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(SWITCH_1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SD_CS_Pin */
  GPIO_InitStruct.Pin = SD_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(SD_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : FLASH_HOLD_Pin flash_CS_Pin CS_BAR_Pin LED_RED_Pin
                           LED_GREEN_Pin */
  GPIO_InitStruct.Pin = FLASH_HOLD_Pin|flash_CS_Pin|CS_BAR_Pin|LED_RED_Pin
                          |LED_GREEN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : FLASH_WP_Pin RF_SEL_Pin RF_SWITCH_Pin GPS_SWITCH_Pin
                           CS_ACCEL_Pin */
  GPIO_InitStruct.Pin = FLASH_WP_Pin|RF_SEL_Pin|RF_SWITCH_Pin|GPS_SWITCH_Pin
                          |CS_ACCEL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : ACCEL_INT_Pin */
  GPIO_InitStruct.Pin = ACCEL_INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ACCEL_INT_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */
/***********************************************FUNCTIONS_DECLARATIONS_BEGIN******************************/

//INTERUPT FUNCTIONS
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	//if the byte received was from the GPS
		if((huart->Instance)==gps_huart->Instance){

			//store the byte
			GPS_RxBuffer[GPS_BufferCounter][GPS_RxCounter]=GPS_receiveByte;
			if(GPS_RxCounter<(sizeof(GPS_RxBuffer[0])-1)){
				GPS_RxCounter++;
			}

			//restart Rx interrupt
			HAL_UART_Receive_IT(gps_huart, &GPS_receiveByte, 1);

			//set timer interrupt
			HAL_TIM_Base_Start_IT(gps_htim);

			//if a new line character has arrived
			if(GPS_receiveByte == '\n'){

				if (GPS_messageReady == 0) {
					if (GPS_BufferCounter == 0) {
						GPS_BufferCounter = 1;
					} else {
						GPS_BufferCounter = 0;
					}

					GPS_messageReady=1;
				}

				GPS_RxCounter=0;

			}

		}

		//if the byte received was from the LoRa
		if((huart->Instance)==lora_huart->Instance){

			if(buffer_erase == 1){
				for(int t=0;t<sizeof(LoRa_RxBuffer);t++){
					LoRa_RxBuffer[t]='\000';
				}
				buffer_erase = 0;
			}

			//store the byte
			LoRa_RxBuffer[LoRa_RxCounter]=LoRa_receiveByte;
			if(LoRa_RxCounter<(sizeof(LoRa_RxBuffer)-1)){
				LoRa_RxCounter++;
			}

			//restart Rx interrupt
			HAL_UART_Receive_IT(lora_huart, &LoRa_receiveByte, 1);

			//set timer interrupt
			HAL_TIM_Base_Start_IT(lora_rx_htim);


		}
}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim){
	//if the GPS message is received
		if((htim->Instance)==gps_htim->Instance){
			HAL_TIM_Base_Stop_IT(gps_htim);
			GPS_RxCounter=0;
		}

		//if the LoRa message is received , check if the message is any of the commands
		if((htim->Instance)==lora_rx_htim->Instance){
			HAL_TIM_Base_Stop_IT(lora_rx_htim);
			LoRa_RxCounter = 0;
			buffer_erase = 1;

			if(check_location_command()==1){
				lora_send_gps();
				if(switch1 == 0 && switch2 == 0 && flight_end == 0){
					HAL_Delay(100);
					uint8_t transmit_message[] = "FM if coordinates are valid send GS_ActivateSensors\n";
					HAL_UART_Transmit(lora_huart, transmit_message,sizeof(transmit_message), 100);
				}
			}

			if(check_activate_sensors_command() == 1 && switch1 == 0 && switch2 == 0 ){
				activate_command = 1;

				if(create_files == 0){
					sd_create_text_sensors("sensors data.txt");
					sd_create_text_gps("gps data.txt");
					create_files = 1;
				}

				uint8_t transmit_activate_sensors_received[] = "FM Sensors Activated, FlightMaster is ready to launch\n";
				HAL_UART_Transmit(lora_huart, transmit_activate_sensors_received,sizeof(transmit_activate_sensors_received), 100);
			}


			if(check_reset_command()==1 && switch1 == 0 && switch2 == 0){
				activate_command =lora_bool =  0;
				flight_start_led = 0;
				apogee = 0;
				start = thrust_end = drogue_parachute = main_parachute = flight_end = counter_end2 = counter_end = 0;
				flight_start_time = thrust_end_time = apogee_time = drogue_deploy_time = main_deploy_time = flight_end_time = 0;
				for(j=0;j<NUMBER_OF_MEASUREMENTS;j++){
					acceleration_array[j]= altitude_array[j]= velocity_array[j] = time_array[j] =0;
				}

				HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, 0);
				HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 0);
				HAL_GPIO_WritePin(DROGUE_GPIO_Port,DROGUE_Pin,0);
				HAL_GPIO_WritePin(MAIN_GPIO_Port,MAIN_Pin,0);

				uint8_t transmit_reset_received[] = "FM Sensors De-Activated\n";
				HAL_UART_Transmit(lora_huart, transmit_reset_received,sizeof(transmit_reset_received), 100);
			}

			if(check_apogee_command() == 1 && switch1 == 0 && switch2 == 0 && flight_end == 1){
				char temp_message[40];

				  for(int k=0 ; k<40;k++){
					  temp_message[k] = '\0';
				  }

				char temp_message1[]= "FM Rocket's apogee was at ";
				char temp_message2[]= " meters!\n";
				char temp_apogee[6];
				sprintf(temp_apogee,"%.1f",apogee);

				strcat(temp_message,temp_message1);
				strcat(temp_message,temp_apogee);
				strcat(temp_message, temp_message2);

				HAL_UART_Transmit(&huart2, temp_message, sizeof(temp_message), 200);

			}

			if(check_simulation_command() == 1 && switch1 == 1 && switch2 == 0 ){
				simulation = 1;
				simulation_time = HAL_GetTick();
				sd_create_text_sensors("sensors data.txt");
				sd_create_text_gps("gps data.txt");
				uint8_t transmit_simulation_received[] = "FM Simulation will start in 12 seconds\n";
				HAL_UART_Transmit(lora_huart, transmit_simulation_received,sizeof(transmit_simulation_received), 100);

			}

			if(check_test_command() == 1 && switch1 == 1 && switch2 == 0 ){
				test_sensors = 1;
				sd_create_text_sensors("sensors data.txt");
				sd_create_text_gps("gps data.txt");
				uint8_t transmit_test_received[] = "FM Sensors Test Begin\n";
				HAL_UART_Transmit(lora_huart, transmit_test_received,sizeof(transmit_test_received), 100);
				HAL_Delay(3000);

			}



		}
		//transmit 5 times sensors data and 1 gps data
		if((htim->Instance)==lora_tx_htim->Instance){

			if(start == 1 && flight_end ==0){
				//transmit sensors data
				if(lora_bool <5){
					lora_send_sensors();
					lora_bool++;
				}
				else if(lora_bool == 5 ){
					if(first_gps_signal == 1){
						lora_send_gps();
					}
					else{
						lora_send_sensors();
					}
					lora_bool = 0;
				}
			}

			if(start == 1 && flight_end == 1){
				lora_bool++;
				//after flight end transmit location once every 10s
				if(lora_bool == 50){
					lora_send_gps();
					lora_bool = 0;
				}
			}
		}
}

//BMP280_FUNCTIONS
float get_altitude() {

	double pres;
	double temp;
	struct bmp280_uncomp_data ucomp_data;
	/* Reading the raw data from sensor */
	bmp280_get_uncomp_data(&ucomp_data, &bmp);


	/* Getting the compensated pressure as floating point value */
	bmp280_get_comp_pres_double(&pres, ucomp_data.uncomp_press, &bmp);


	/* Getting the compensated temperature as floating point value */
	bmp280_get_comp_temp_double(&temp, ucomp_data.uncomp_temp, &bmp);

	return (float)(((pow((101330 / pres), 1 / 5.257) - 1.0) * (temp + 273.15)) / 0.0065);

}
void delay_ms(uint32_t period_ms)
{
    /* Implement the delay routine according to the target machine */
	HAL_Delay(period_ms);
}
int8_t spi_reg_write(uint8_t cs, uint8_t reg_addr, uint8_t *reg_data, uint16_t length)
{

	reg_addr &= ~0x80;
	CS_BAR_GPIO_Port -> ODR &= ~CS_BAR_Pin;
	HAL_SPI_Transmit(&hspi3,&reg_addr,1,50);
	HAL_SPI_Transmit(&hspi3,reg_data,length,length*50);
	CS_BAR_GPIO_Port -> ODR |= CS_BAR_Pin;
    return BMP280_OK;
}
int8_t spi_reg_read(uint8_t cs, uint8_t reg_addr, uint8_t *reg_data, uint16_t length)
{
	reg_addr |= 0x80;
	CS_BAR_GPIO_Port -> ODR &= ~CS_BAR_Pin;
	HAL_SPI_Transmit(&hspi3, &reg_addr,1,50);
	HAL_SPI_Receive(&hspi3,reg_data,length,length*50);
	CS_BAR_GPIO_Port -> ODR |= CS_BAR_Pin;
    return BMP280_OK;
}
void BMP280_setup(){
	/**********************************BMP280 setup ******************************************/

		struct bmp280_config conf;

		/* Map the delay function pointer with the function responsible for implementing the delay */
		bmp.delay_ms = delay_ms;

		bmp.dev_id = 0;
		bmp.read = spi_reg_read;
		bmp.write = spi_reg_write;
		bmp.intf = BMP280_SPI_INTF;

		bmp280_init(&bmp);


		bmp280_soft_reset(&bmp);

		/* Always read the current settings before writing, especially when
		 * all the configuration is not modified
		 */
		bmp280_get_config(&conf, &bmp);


		/* configuring the temperature oversampling, filter coefficient and output data rate */
		/* Overwrite the desired settings */
		conf.filter = BMP280_FILTER_OFF;

		/* Pressure oversampling set at 2x */
		conf.os_pres = BMP280_OS_2X;

		/* Setting the output data rate */
		conf.odr = BMP280_ODR_62_5_MS;
		bmp280_set_config(&conf, &bmp);


		/* Always set the power mode after setting the configuration */
		bmp280_set_power_mode(BMP280_NORMAL_MODE, &bmp);


		/*For Setup*/
		get_altitude();

		HAL_Delay(500);

}

//SIMULATION_FUNCTIONS
float simulate_acceleration(){
	//in every return adds +10 due to accelerometer function
	float fault,time;
	fault = (1000 - (float) (rand() % 2000)) / 1000; // +- 1m/s^2 fault

	time=HAL_GetTick()- simulation_time;
	time=time-SIMULATION_START_TIME;
	time=time/1000;    // time = 0 when flight starts

	if(time<0){ // before flight start
		return 10 + fault;
	}

	if(time >=0 && time<2){  // 0-2s initial thrust phase a=100m/s^2
		return 100+fault+10;
	}

	if( time >=2 && time <5){ // 2-5s slowly reducing acceleration
		return 166.66-37.67*time + fault+10;
	}

	if(time >=5 && time <297.5){
		return fault;
	}

	if(time >=297.5){ // after landing
		return 10+fault;
	}

	return 0 ;

}
float simulate_altitude(){
	float fault,time,h; // t for time h for height
	fault = (500 - (float) (rand() % 1000)) / 1000;// +-0.5 m fault


	time=HAL_GetTick()- simulation_time;
	time=time-SIMULATION_START_TIME;
	time=time/1000;

	if(time<0){ // before flight start
		return fault;
	}

	if(time >=0 && time<2){  // 0-2s initial thrust phase a=100m/s^2
		h=50*time*time ; // 1/2*a*t^2
		return h+fault;
	}

	if( time >=2 && time <5){ // 2-5s slowly reducing acceleration
		h=83.33*time*time -5.55*time*time*time -86.6*time+85;
		return h+fault;
	}

	if(time >=5 && time <25){ // added negative acceleration due to drag
		h = 1042 + 330*(time-5)-8.25*(time-5)*(time-5);
		return h+fault;
	}

	if(time>=25 && time <27){
		h=4342-5*(time-25)*(time-25);
		return h+fault;
	}

	if(time>=27 && time<220){
		h=4322-20*(time-27);
		return h+fault;
	}

	if(time>=220 && time<297.5){
		h=465-6*(time-220);
		return h+fault;

	}

	if(time>=297.5){
		return fault;
	}

	return 0 ;
}
void get_simulation_measurements(){

	  //get altitude and velocity
	 	get_altitude();
	 	altitude_array[i] = simulate_altitude();
	 	time_array[i] =  HAL_GetTick() - flight_start_time;

	 	if(i < NUMBER_OF_MEASUREMENTS-1){
	 		velocity_array[i] = (altitude_array[i] - altitude_array[i+1])/ ((time_array[i] - time_array[i+1]) / 1000);
	 	}

	 	if(i == NUMBER_OF_MEASUREMENTS-1){
	 		velocity_array[i] = (altitude_array[i] - altitude_array[0])/ ((time_array[i] - time_array[0]) / 1000);
	 	}


	 	datasd_sensors.time = time_array[i];
	 	datasd_sensors.height = altitude_array[i];
	 	datasd_sensors.velocity = velocity_array[i];

	 	//get axis acceleration
	 	datasd_sensors.x_acceleration = get_x_accel(accelerometer);
	 	datasd_sensors.y_acceleration = get_y_accel(accelerometer);
	    get_z_accel(accelerometer);
	 	datasd_sensors.z_acceleration  = simulate_acceleration();

	 	acceleration_array[i] = sqrt(datasd_sensors.x_acceleration * datasd_sensors.x_acceleration
	 			+ datasd_sensors.y_acceleration * datasd_sensors.y_acceleration
	 			+ datasd_sensors.z_acceleration * datasd_sensors.z_acceleration);


	 	//get angular momentum
	 	datasd_sensors.x_rotation = get_x_rotation(accelerometer);
	 	datasd_sensors.y_rotation = get_y_rotation(accelerometer);
	 	datasd_sensors.z_rotation = get_z_rotation(accelerometer);


}

//GPS FUNCTIONS
float charToFloat(uint8_t c){
	float f=0;
	c-=48;
	f=(float)c;
	return f;
}
void checkGPSMessage() {

	//find the correct buffer to parse
	uint8_t arrayToRead;
	if (GPS_BufferCounter == 0) {
		arrayToRead = 1;
	} else {
		arrayToRead = 0;
	}

	//check if the line is the one with the lat - lon values
	uint8_t initials[] = "$GPGGA";

	for(int i =0; i<sizeof(initials)-1; i++){
		if(initials[i] != GPS_RxBuffer[arrayToRead][i]){
			GPS_messageReady = 0;
			return;
		}
	}

	__NOP();
	//if there is no GPS signal
	if((GPS_RxBuffer[arrayToRead][7] == ',') || (GPS_RxBuffer[arrayToRead][17] == ',')){

		GPS_messageReady = 0;
		return;
	}

	uint8_t UTCtimeString[15];
	uint8_t latString[15];
	uint8_t lonString[15];
	uint8_t satellitesString[15];
	uint8_t HDOPString[15];
	uint8_t altitudeString[15];
	uint8_t sealevelString[15];

	uint16_t cursor = 0;
	uint8_t commaCounter=0;

	/**********************find the comma before UTC time (1)***********************************/
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==1  ){
			break;
		}
	}

	/************************extract the UTC time string***********************************************/
	int i=0;
	cursor ++;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){

		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter>1 || GPS_RxBuffer[arrayToRead][cursor] == '.' ){
			break;
		}

		UTCtimeString[i++]=GPS_RxBuffer[arrayToRead][cursor];
	}

	/**********************find the comma before latitude (2)***********************************/
	cursor++;//why
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==2){
			break;
		}
	}

	/************************extract the lat string***********************************************/
    i=0;
	cursor ++;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){

		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter>2){
			break;
		}

		latString[i++]=GPS_RxBuffer[arrayToRead][cursor];
	}

	/***********************find the comma before the longtitude (4)*******************************/
	cursor ++;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==4){
			break;
		}
	}

	/******************************extract lon string*********************************************/
	cursor ++;
	i=0;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter>4){
			break;
		}
		lonString[i++]=GPS_RxBuffer[arrayToRead][cursor];
	}

	/***************************find the comma before the satellites(7)***************************/
	cursor ++;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==7){
			break;
		}
	}

	/*********************************extract number of satellites string********************************/
	cursor ++;
	i=0;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==8){
			break;
		}
		satellitesString[i++]=GPS_RxBuffer[arrayToRead][cursor];
	}


	/*********************************extract HDOP string********************************/
	cursor ++;
	i=0;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==9){
			break;
		}
		HDOPString[i++]=GPS_RxBuffer[arrayToRead][cursor];
	}

	/*********************************extract altitude string********************************/
	cursor ++;
	i=0;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==10){
			break;
		}
		altitudeString[i++]=GPS_RxBuffer[arrayToRead][cursor];
	}

	/***************************find the comma before the sea level(11)***************************/
	cursor ++;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==11){
			break;
		}
	}

	/*********************************extract sea level string********************************/
	cursor ++;
	i=0;
	for(; cursor < sizeof(GPS_RxBuffer[arrayToRead]); cursor ++){
		if(GPS_RxBuffer[arrayToRead][cursor] == ','){
			commaCounter++;
		}
		if(commaCounter==12){
			break;
		}
		sealevelString[i++]=GPS_RxBuffer[arrayToRead][cursor];
	}




	/****************************convert UTC time string to float**************************/

	datasd_gps.current_time_UTC=0;
	datasd_gps.current_time_UTC=charToFloat(UTCtimeString[0])*100000 + charToFloat(UTCtimeString[1])*10000 +
			charToFloat(UTCtimeString[2])*1000 + charToFloat(UTCtimeString[3])*100 +
			charToFloat(UTCtimeString[4])*10 + charToFloat(UTCtimeString[5]);

	if(datasd_gps.current_time_UTC>250000){
		datasd_gps.current_time_UTC =0;
		return;
	}


	/*****************************convert lat string to float***********************/
	uint8_t dotPlace=0;
	for(; dotPlace<sizeof(latString); dotPlace++){
		if(latString[dotPlace] == '.'){
			break;
		}
	}

	if(dotPlace < 4){
		return;
	}

	datasd_gps.lat=0;
	for(int j = dotPlace - 3; j>=0; j--){
		float digit = charToFloat(latString[j]);
		for(int k=0; k<((dotPlace-3) - j); k++){
			digit *= 10;
		}
		datasd_gps.lat += digit;
	}

	float degrees=0;
	for (int j = dotPlace - 2; j <= dotPlace + 5; j++) {

		if (j != dotPlace) {

			float digit = charToFloat(latString[j]);

			uint8_t repCounter = j - (dotPlace - 3);
			if(j > dotPlace){
				repCounter--;
			}
			for (int k = 0; k < repCounter; k++) {
				digit /= 10;
			}
			degrees += digit;

		}
	}

	degrees*=10;
	datasd_gps.lat += degrees / 6;

	/****************************convert lon string to float************************/
	for(; dotPlace<sizeof(lonString); dotPlace++){
		if(lonString[dotPlace] == '.'){
			break;
		}
	}

	if(dotPlace < 4){
		return;
	}

	datasd_gps.lon = 0;
	for (int j = dotPlace - 3; j >= 0; j--) {
		float digit = charToFloat(lonString[j]);
		for(int k=0; k<((dotPlace-3) - j); k++){
			digit *= 10;
		}
		datasd_gps.lon += digit;
	}

	degrees = 0;
	for (int j = dotPlace - 2; j <= dotPlace + 5; j++) {

		if (j != dotPlace) {

			float digit = charToFloat(lonString[j]);
			uint8_t repCounter = j - (dotPlace - 3);
			if (j > dotPlace) {
				repCounter--;
			}
			for (int k = 0; k < repCounter; k++) {
				digit /= 10;
			}
			degrees += digit;

		}
	}

	degrees *= 10;
	datasd_gps.lon += degrees / 6;

	/****************************convert satellites string to float************************/
	float decade=0;
	float unit=0;

	decade= charToFloat(satellitesString[0]);
	unit = charToFloat(satellitesString[1]);

	datasd_gps.satellites = 10*decade + unit;

	/****************************convert HDOP string to float************************/
	for(dotPlace=0; dotPlace<sizeof(HDOPString); dotPlace++){
		if(HDOPString[dotPlace] == '.'){
			break;
		}
	}

	float after1;

	if(dotPlace == 1 ){
		datasd_gps.HDOP=0;
		unit = charToFloat(HDOPString[0]);
		after1=	charToFloat(HDOPString[2]) ;
		datasd_gps.HDOP = unit + after1*0.1 ;
	}

	if(dotPlace == 2 ){
		datasd_gps.HDOP=0;
		 decade = charToFloat(HDOPString[0]);
		 unit =	charToFloat(HDOPString[1]);
		 after1= charToFloat(HDOPString[3]);
		 datasd_gps.HDOP = decade*10 + unit + after1*0.1;
	}

	/****************************convert altitude string to float************************/
	for(dotPlace=0; dotPlace<sizeof(altitudeString); dotPlace++){
		if(altitudeString[dotPlace] == '.'){
			break;
		}
	}

	if(dotPlace == 1 ){
		datasd_gps.altitude = charToFloat(altitudeString[0]) + charToFloat(altitudeString[2])*0.1;
	}

	if(dotPlace == 2 ){
		datasd_gps.altitude = charToFloat(altitudeString[0])*10 + charToFloat(altitudeString[1])+
				charToFloat(altitudeString[3])*0.1;
	}

	if(dotPlace == 3){
		datasd_gps.altitude = charToFloat(altitudeString[0])*100 + charToFloat(altitudeString[1])*10+
				charToFloat(altitudeString[2])+ charToFloat(altitudeString[4])*0.1 ;
	}

	if(dotPlace == 4){
		datasd_gps.altitude = charToFloat(altitudeString[0])*1000 + charToFloat(altitudeString[1])*100+
				charToFloat(altitudeString[2])*10+ charToFloat(altitudeString[3]) + charToFloat(altitudeString[5])*0.1 ;

	}

	/****************************convert sea level string to float************************/
	for(dotPlace=0; dotPlace<sizeof(sealevelString); dotPlace++){
		if(sealevelString[dotPlace] == '.'){
			break;
		}
	}

	if(dotPlace == 1 ){
		datasd_gps.sea_level = charToFloat(sealevelString[0]) + charToFloat(sealevelString[2])*0.1;
	}

	if(dotPlace == 2 ){
		datasd_gps.sea_level = charToFloat(sealevelString[0])*10 + charToFloat(sealevelString[1])+
				charToFloat(sealevelString[3])*0.1;
	}

	if(dotPlace == 3){
		datasd_gps.sea_level = charToFloat(sealevelString[0])*100 + charToFloat(sealevelString[1])*10+
				charToFloat(sealevelString[2])+ charToFloat(sealevelString[4])*0.1 ;
	}

	if(dotPlace == 4){
		datasd_gps.sea_level = charToFloat(sealevelString[0])*1000 + charToFloat(sealevelString[1])*100+
				charToFloat(sealevelString[2])*10+ charToFloat(sealevelString[3]) + charToFloat(sealevelString[5])*0.1 ;

	}

	datasd_gps.flight_time = HAL_GetTick();
	datasd_gps.flight_time = datasd_gps.flight_time - flight_start_time;


	if(first_gps_signal == 0){
		uint8_t transmit_gps_signal[] = "FM GPS has obtained signal\n";
		HAL_UART_Transmit(lora_huart, transmit_gps_signal,sizeof(transmit_gps_signal), 100);
		HAL_Delay(50);
		lora_send_gps();
		first_gps_signal = 1;
	}

	  if(start ==1 && flight_end == 0){
		  write_data_gps(datasd_gps);
	  }

	GPS_messageReady = 0;
}

//GENERAL_PURPOSE_FUNCTIONS
void get_sensors_measurements(){


    //get altitude and velocity
	altitude_array[i]=get_altitude()-initial_altitude;
	time_array[i] = ((float) HAL_GetTick()) - flight_start_time;

	if(i < NUMBER_OF_MEASUREMENTS-1){
		velocity_array[i] = (altitude_array[i] - altitude_array[i+1])/ ((time_array[i] - time_array[i+1]) / 1000);
	}

	if(i == NUMBER_OF_MEASUREMENTS-1){
		velocity_array[i] = (altitude_array[i] - altitude_array[0])/ ((time_array[i] - time_array[0]) / 1000);
	}


	datasd_sensors.time = time_array[i];
	datasd_sensors.height = altitude_array[i];
	datasd_sensors.velocity = velocity_array[i];

	//get axis acceleration
	datasd_sensors.x_acceleration = get_x_accel(accelerometer);
	datasd_sensors.y_acceleration = get_y_accel(accelerometer);
	datasd_sensors.z_acceleration = get_z_accel(accelerometer);

	acceleration_array[i] = sqrt(datasd_sensors.x_acceleration * datasd_sensors.x_acceleration
			+ datasd_sensors.y_acceleration * datasd_sensors.y_acceleration
			+ datasd_sensors.z_acceleration * datasd_sensors.z_acceleration);


	//get angular momentum
	datasd_sensors.x_rotation = get_x_rotation(accelerometer);
	datasd_sensors.y_rotation = get_y_rotation(accelerometer);
	datasd_sensors.z_rotation = get_z_rotation(accelerometer);

}
void lora_send_sensors(){
	 	  char temp_velocity[49];
		  char temp_accelerationX[6];
		  char temp_accelerationY[6];
		  char temp_accelerationZ[6];
		  char temp_rotationZ[6];
		  char temp_altitude[6];
		  char temp_time[6];
		  char temp_tab[]="\t";
		  char temp_enter[]="\n";

		  for(int k=0; k<49 ; k++){
			  temp_velocity[k] = '\0';
		  }

		  //float accel_norm = sqrt(datasd_sensors.x_acceleration * datasd_sensors.x_acceleration +
		  //datasd_sensors.y_acceleration * datasd_sensors.y_acceleration +
		  //datasd_sensors.z_acceleration * datasd_sensors.z_acceleration);

		  sprintf(temp_velocity,"%.1f",datasd_sensors.velocity);                // convert velocity float to string
	  	  sprintf(temp_accelerationX,"%.1f",datasd_sensors.x_acceleration);        // convert accelerationX
	  	  sprintf(temp_accelerationY,"%.1f",datasd_sensors.y_acceleration);        // convert accelerationY
	  	  sprintf(temp_accelerationZ,"%.1f",datasd_sensors.z_acceleration);        // convert accelerationZ
	  	  sprintf(temp_rotationZ,"%.1f",datasd_sensors.z_rotation);        // convert rotationZ
	  	  sprintf(temp_altitude,"%.1f",datasd_sensors.height);                // convert altitude
	  	  sprintf(temp_time,"%.2f",(datasd_sensors.time/1000));                        // convert time



	  	  strcat(temp_velocity,temp_tab);
	  	  strcat(temp_velocity,temp_accelerationX);
	  	  strcat(temp_velocity,temp_tab);
	  	  strcat(temp_velocity,temp_accelerationY);
	  	  strcat(temp_velocity,temp_tab);
	  	  strcat(temp_velocity,temp_accelerationZ);
	  	  strcat(temp_velocity,temp_tab);

	  	  strcat(temp_velocity,temp_rotationZ);
	  	  strcat(temp_velocity,temp_tab);

	  	  strcat(temp_velocity,temp_altitude);
	  	  strcat(temp_velocity,temp_tab );

	  	  strcat(temp_velocity,temp_time );
	  	  strcat(temp_velocity,temp_enter);


	  	  char temp_overall[55]="FM_S\t";

	  	  if(thrust_end == 1){
	  		  temp_overall[4]='T';//thrust
	  		  temp_overall[5]='E';//end
	  		  temp_overall[6]='\t';
	  	  }

	  	  if(drogue_parachute == 1){
	  		  temp_overall[4]='D';//drogue
	  		  temp_overall[5]='P';//parachute
	  		  temp_overall[6]='\t';
	  	  }

	  	  if(main_parachute == 1){
	  		  temp_overall[4]='M';//main
	  		  temp_overall[5]='P';//parachute
	  		  temp_overall[6]='\t';
	  	  }
	  	  strcat(temp_overall, temp_velocity);

	  	HAL_UART_Transmit(&huart2, temp_overall, sizeof(temp_overall), 100);
}
void lora_send_gps(){

	  char temp_UTCtimehours[36];
	  char temp_UTCtimeminutes[2];
	  char temp_UTCtimeseconds[2];
	  char temp_latitude[9];
	  char temp_longtitude[9];
	  char temp_altitude[6];
	  char temp_tab[]="\t";
	  char temp_updown[]=":";
	  char temp_enter[]="\n";
	  char temp_zero[]="0";

	  for(int k=0 ; k<40;k++){
		  temp_UTCtimehours[k] = '\0';
	  }

	  int hours;
	  int minutes;
	  int seconds;

	  hours = datasd_gps.current_time_UTC / 10000;
	  minutes = datasd_gps.current_time_UTC / 100;
	  minutes = minutes % 100;
	  seconds = ((int)datasd_gps.current_time_UTC) % 100;


	  sprintf(temp_UTCtimehours,"%d",hours);               	 // convert float to string
	  sprintf(temp_UTCtimeminutes,"%d",minutes);
	  sprintf(temp_UTCtimeseconds,"%d",seconds);
	  sprintf(temp_latitude,"%.6f",datasd_gps.lat);
	  sprintf(temp_longtitude,"%.6f",datasd_gps.lon);
	  sprintf(temp_altitude,"%.1f",datasd_gps.altitude);


	  strcat(temp_UTCtimehours,temp_updown );
	  if(minutes<10){
		  strcat(temp_UTCtimehours,temp_zero);
	  }
	  strcat(temp_UTCtimehours,temp_UTCtimeminutes );
	  strcat(temp_UTCtimehours,temp_updown );
	  if(seconds<10){
		  strcat(temp_UTCtimehours,temp_zero);
	  }
	  strcat(temp_UTCtimehours,temp_UTCtimeseconds );
	  strcat(temp_UTCtimehours,temp_tab );

	  strcat(temp_UTCtimehours,temp_latitude );
	  strcat(temp_UTCtimehours,temp_tab );

	  strcat(temp_UTCtimehours,temp_longtitude );
	  strcat(temp_UTCtimehours,temp_tab );

	 strcat(temp_UTCtimehours,temp_altitude );
	 strcat(temp_UTCtimehours,temp_enter );

	char temp_overall[41]="FM_G\t";
	strcat(temp_overall, temp_UTCtimehours);
	HAL_UART_Transmit(&huart2, temp_overall, sizeof(temp_overall), 200);

}
void lora_set_parameters(){
	//MO M1 pins should be connected to power supply
	//connect a logic analyzer in the TX RX pins to see what the lora replies are
	//need to set the 9600 baud rate in UART


	  uint8_t get_param_array[3];
	  get_param_array[0]= 0xC1;
	  get_param_array[1]= 0xC1;
	  get_param_array[2]= 0xC1;
	  HAL_UART_Transmit(lora_huart, get_param_array, sizeof(get_param_array), 200);
	  //after you send this command the LoRa sends back the params

	  HAL_Delay(100);

	  uint8_t set_param_array[6];
	  set_param_array[0] = 0xC0;
	  set_param_array[1] = 0x00;
	  set_param_array[2] = 0x00;
	  set_param_array[3] = 0x3C; //0x3A -> 115200 baud, 2.4kbps air data rate ,0x3B -> 4.8kbps ,0x3C -> 9.6kbps , 0x3D -> 19.2kbps
	  set_param_array[4] = 0x17;
	  set_param_array[5] = 0x44;

	  HAL_UART_Transmit(lora_huart, set_param_array, sizeof(set_param_array), 200);
	  //set the new params

	  HAL_Delay(100);

	  HAL_UART_Transmit(lora_huart, get_param_array, sizeof(get_param_array), 200);
	  //confirm that the params are set correctly

}
void flight_checks(){

	//if the DROGUE or MAIN pin is open for more than OPEN_SWITCH_TIME close it
	if (HAL_GetTick()> drogue_deploy_time + flight_start_time + OPEN_SWITCH_TIME && drogue_parachute == 1 && main_parachute == 0){
		HAL_GPIO_WritePin(DROGUE_GPIO_Port, DROGUE_Pin, 0);
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 0);
	}
	if (HAL_GetTick()>main_deploy_time + flight_start_time + OPEN_SWITCH_TIME && main_parachute == 1) {
		HAL_GPIO_WritePin(MAIN_GPIO_Port, MAIN_Pin, 0);
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 0);
	}

	//check for apogee
	if (apogee < datasd_sensors.height) {
		apogee = datasd_sensors.height ;
		apogee_time = datasd_sensors.time;
	}


	//reset all counters
	counter_apogee = counter_thrust = counter_main_parachute = temp_time = 0;

	//store the time of the what is probably the first measurement that meets the requirements
	if (i < NUMBER_OF_MEASUREMENTS - 3) {
		temp_time = time_array[i + 3];
	}
	if (i >= NUMBER_OF_MEASUREMENTS - 3) {
		temp_time = time_array[i + 1 - NUMBER_OF_SUCCESSFUL_MEASUREMENTS];
	}

	//check all the conditions
	for (j = 0; j < NUMBER_OF_MEASUREMENTS; j++) {
		if (acceleration_array[j] < THRUST_END_ACC && datasd_sensors.time > 3000 )
			counter_thrust++;

		if (velocity_array[j] < APOGGE_DETECT_VELOCITY  && datasd_sensors.time > MIN_TIME_PASSED_FOR_APOGEE_DETECT)
			counter_apogee++;

		if (altitude_array[j] < MAIN_DEPLOY_HEIGHT && drogue_parachute == 1)
			counter_main_parachute++;
	}

	//check thrust end
	if (counter_thrust > NUMBER_OF_SUCCESSFUL_MEASUREMENTS && thrust_end != 1) {
		thrust_end = 1;
		thrust_end_time = temp_time;
	}

	//check apogee reach to deploy drogue parachute
	if (counter_apogee > NUMBER_OF_SUCCESSFUL_MEASUREMENTS / 3 && drogue_parachute != 1   ) {
		drogue_parachute = 1;
		if(simulation == 0 && apogee > 150 ){
			HAL_GPIO_WritePin(DROGUE_GPIO_Port, DROGUE_Pin, 1);
		}
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 1);
		drogue_deploy_time = time_array[i];
	}

	//check altitude to deploy main parachute
	if (counter_main_parachute > NUMBER_OF_SUCCESSFUL_MEASUREMENTS / 2 && main_parachute != 1) {
		main_parachute = 1;
		if(simulation == 0 && apogee > 150){
			HAL_GPIO_WritePin(MAIN_GPIO_Port, MAIN_Pin, 1);
		}
		HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 1);
		main_deploy_time = time_array[i] ;
	}

	//flight end check
	if(i<NUMBER_OF_MEASUREMENTS-1){

		if ( abs((altitude_array[i + 1] - altitude_array[i]) < 2) && drogue_parachute == 1) {
			counter_end++;
		}
		else {
			counter_end = 0;
		}
	}

	if(i == NUMBER_OF_MEASUREMENTS-1){

		if ( abs((altitude_array[i] - altitude_array[0]) < 2) && drogue_parachute == 1) {
			counter_end++;
		}
		else {
			counter_end = 0;
		}
	}

	if (counter_end > NUMBER_OF_SUCCESSFUL_MEASUREMENTS && drogue_parachute == 1) {
		counter_end2++;
	}

	//if the sensors detect that flight has ended or more than 12 minutes since flight start have passed
	if (flight_end!=1 && ((counter_end2 > FLIGHT_END_COUNTER ) || (HAL_GetTick() - flight_start_time) > 720000)) {
		flight_end_time = temp_time;
		flight_end = 1;

		//write in sd
		sd_write_general_info(thrust_end_time, apogee, apogee_time,drogue_deploy_time, main_deploy_time, flight_end_time);
		HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, 1);

	}
}
void check_switches(){
	  if (switch1 == 1 && switch2 == 1) { //both switches down , read data from flash
			flash_read_and_write_to_sd_sensors("flash sensors data.txt");
			flash_read_and_write_to_sd_gps("flash gps data.txt");

			HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, 1); //when its done open both leds
			HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 1);

			while (1) {
			}
		}

		if (switch1 == 0 && switch2 == 1) { //left switch down, right switch up , clear flash
			flash_clear();

			HAL_GPIO_WritePin(LED_GREEN_GPIO_Port, LED_GREEN_Pin, 1); //when its done open green led and buzz once

			while (1) {
			}
		}

		if (switch1 == 1 && switch2 == 0) { //left switch up , right switch down , test sensors or run simulation

			uint8_t transmit_test_sensors[] = "FM in Test Mode send GS_Launch to start simulation or GS_TestSensors to test sensors\n";
			HAL_UART_Transmit(lora_huart, transmit_test_sensors,sizeof(transmit_test_sensors), 100);


			int space= 0 ;
			space = flash_free_space_check();
			if ( space == 0){
				while(1){
					uint8_t transmit_error[] = "FM not enough space in flash memory\n";
					HAL_UART_Transmit(lora_huart, transmit_error,sizeof(transmit_error), 100);
					HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 1);
				}
			}

			while (1) {
				/**************************************simulation code******************************************/

				  if(GPS_messageReady==1){
					  checkGPSMessage();
				  }


				if (test_sensors == 1) {

					for(int u= 0; u<12 ; u++){
						get_sensors_measurements();
						initial_altitude = altitude_array[i] + initial_altitude;
						HAL_Delay(50);
						i++;
						if (i == NUMBER_OF_MEASUREMENTS) { //dont go out of arrays borders
							i = 0;
						}

					}

					for (int w = 0; w < 20; w++) {
						get_sensors_measurements();
						write_data_sensors(datasd_sensors);
						lora_send_sensors();
						HAL_Delay(50);

						i++;
						if (i == NUMBER_OF_MEASUREMENTS) { //dont go out of arrays borders
							i = 0;
						}
					}

					uint8_t transmit_test_sensors_end[] = "FM Sensors Test Ended\n";
					HAL_UART_Transmit(lora_huart, transmit_test_sensors_end,sizeof(transmit_test_sensors_end), 100);
					test_sensors = 0;
				}

				if (simulation == 1 && flight_end == 0) {

					get_simulation_measurements();

					//if at least one acceleration value is above the limit start transmitting data
					if(start == 0 ){
						if (acceleration_array[i] > INIT_ACC) {
							start = 1;
							flight_start_time = HAL_GetTick();
							datasd_sensors.time = 0;
							datasd_sensors.height = 0;
							datasd_sensors.velocity = 0;
							initial_altitude = altitude_array[i] + initial_altitude;
							lora_send_sensors();
							HAL_TIM_Base_Start_IT(lora_tx_htim);
						}
					}

					if (start == 1) {
						write_data_sensors(datasd_sensors);
						flight_checks();
					}

					i++;
					if (i == NUMBER_OF_MEASUREMENTS) { //dont go out of arrays borders
						i = 0;
					}
				}
			}
		}

		if (switch1 == 0 && switch2 == 0) {  //both switches up , run flight code
			int space= 0 ;
			space = flash_free_space_check();
			if (space == 1) { //if there is data in the flash memory write
				uint8_t transmit_armed[] ="FM flight computer is activated, send GS_SendLocation to confirm GPS gained signal\n";
				HAL_UART_Transmit(lora_huart, transmit_armed,sizeof(transmit_armed), 100);
			}

			if ( space == 0){
				uint8_t transmit_error[] = "FM not enough space in flash memory\n";
				HAL_UART_Transmit(lora_huart, transmit_error,sizeof(transmit_error), 100);
				while(1){
					HAL_GPIO_WritePin(LED_RED_GPIO_Port, LED_RED_Pin, 1);
				}
			}

		}

}
void check_igniters_continuity(){
	  //check igniters continuity (should have pyro battery connected)
	  HAL_GPIO_WritePin(DROGUE_CHECK_GPIO_Port, DROGUE_CHECK_Pin,1);
	  HAL_GPIO_WritePin(MAIN_CHECK_GPIO_Port, MAIN_CHECK_Pin,1);

	  HAL_Delay(50);

	  drogue_continuity =! HAL_GPIO_ReadPin(DROGUE_CONTINUITY_GPIO_Port, DROGUE_CONTINUITY_Pin);
	  main_continuity =! HAL_GPIO_ReadPin(MAIN_CONTINUITY_GPIO_Port, MAIN_CONTINUITY_Pin);

	  HAL_GPIO_WritePin(DROGUE_CHECK_GPIO_Port, DROGUE_CHECK_Pin,0);
	  HAL_GPIO_WritePin(MAIN_CHECK_GPIO_Port, MAIN_CHECK_Pin,0);

	  if(drogue_continuity==1 && main_continuity==1){//both igniters connected ( 3 beeps)
		 for(int j=0;j<BUZZER_REPEAT;j++){
			  for(int i=0;i<3;i++){
				  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
				  HAL_Delay(100);
				  HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
				  HAL_Delay(100);
			  }
			  HAL_Delay(1000);
		 }
	  }
	  if(drogue_continuity==1 && main_continuity==0){//main igniter not connected (2 beeps)
		 for(int j=0;j<BUZZER_REPEAT;j++){
			  for(int i=0;i<2;i++){
				  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
				  HAL_Delay(100);
				  HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
				  HAL_Delay(100);
			  }
			  HAL_Delay(1100);
		 }

	  }
	  if(drogue_continuity==0 && main_continuity==1){//drogue igniter not connected ( 1 beep)
		for(int j=0;j<BUZZER_REPEAT;j++){
			 HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
			 HAL_Delay(100);
			 HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
			 HAL_Delay(1300);
		 }

	  }
	  if(drogue_continuity==0 && main_continuity==0){//both igniters not connected (continuous beep)
		for(int j=0;j<BUZZER_REPEAT;j++){
			 HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
			 HAL_Delay(3000);
			 HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
			 HAL_Delay(900);
		 }
	  }

}
int check_location_command(){
		uint8_t gps_array[] = "GS_SendLocation";
		int gps_counter = 0;

		for (int t = 0; t < sizeof(gps_array); t++) {
			if (LoRa_RxBuffer[t] == gps_array[t]) {
				gps_counter++;
			}
		}

		if (gps_counter == sizeof(gps_array)-1) {
			return 1;
		}
		return 0;
}
int check_activate_sensors_command(){
		uint8_t activate_array[] = "GS_ActivateSensors";

		int activate_counter = 0;

		for (int t = 0; t < sizeof(activate_array); t++) {
			if (LoRa_RxBuffer[t] == activate_array[t]) {
				activate_counter++;
			}
		}

		if (activate_counter == sizeof(activate_array)-1) {
			return 1;
		}

		return 0;
	}
int check_reset_command(){
		uint8_t abort_array[] = "GS_Reset";
		int abort_counter = 0;

		for (int t = 0; t < sizeof(abort_array); t++) {
			if (LoRa_RxBuffer[t] == abort_array[t]) {
				abort_counter++;
			}
		}

		if (abort_counter == sizeof(abort_array)-1) {
			return 1;
		}
		return 0;

	}
int check_test_command(){
	uint8_t test_array[] = "GS_TestSensors";
	int test_counter = 0;

	for (int t = 0; t < sizeof(test_array); t++) {
		if (LoRa_RxBuffer[t] == test_array[t]) {
			test_counter++;
		}
	}

	if (test_counter == sizeof(test_array)-1) {
		return 1;
	}
	return 0;

}
int check_simulation_command(){
	uint8_t simulation_array[] = "GS_Launch";
	int simulation_counter = 0;

	for (int t = 0; t < sizeof(simulation_array); t++) {
		if (LoRa_RxBuffer[t] == simulation_array[t]) {
			simulation_counter++;
		}
	}

	if (simulation_counter == sizeof(simulation_array)-1) {
		return 1;
	}
	return 0;

}
int check_apogee_command(){

	uint8_t apogee_array[] = "GS_SendApogee";
	int matrix_counter = 0;

	for (int t = 0; t < sizeof(apogee_array); t++) {
		if (LoRa_RxBuffer[t] == apogee_array[t]) {
			matrix_counter++;
		}
	}

	if (matrix_counter == sizeof(apogee_array)-1) {
		return 1;
	}
	return 0;

}


/***********************************************FUNCTIONS_DECLARATIONS_END******************************/
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
