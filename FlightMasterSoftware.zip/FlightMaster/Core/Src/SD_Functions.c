/*
 * SD_Functions.c
 *
 *  Created on: Mar 22, 2023
 *      Author: Vaggelis
 */

#include "string.h"
#include "fatfs.h"
#include "math.h"
#include "SD_Functions.h"
#include "fatfs_sd.h"
#include <stdio.h>
#include "main.h"



void sd_write_data_sensors(struct datasd_sensors datasd_sensors,char filename[]){

	  char temp_velocity[200];
	  char temp_acceleration[20];
	  char temp_accelerationX[20];
	  char temp_accelerationY[20];
	  char temp_accelerationZ[20];
	  char temp_rotationX[20];
	  char temp_rotationY[20];
	  char temp_rotationZ[20];
	  char temp_altitude[20];
	  char temp_time[20];
	  char temp_tab[]="\t";
	  char temp_enter[]="\n";

	  float accel_norm = sqrt(datasd_sensors.x_acceleration * datasd_sensors.x_acceleration + datasd_sensors.y_acceleration * datasd_sensors.y_acceleration + datasd_sensors.z_acceleration * datasd_sensors.z_acceleration);

	  sprintf(temp_velocity,"%.2f",datasd_sensors.velocity);                // convert velocity float to string
  	  sprintf(temp_accelerationX,"%.2f",datasd_sensors.x_acceleration);        // convert accelerationX
  	  sprintf(temp_accelerationY,"%.2f",datasd_sensors.y_acceleration);        // convert accelerationY
  	  sprintf(temp_accelerationZ,"%.2f",datasd_sensors.z_acceleration);        // convert accelerationZ
  	  sprintf(temp_acceleration,"%.2f",accel_norm);						//convert acceleration
  	  sprintf(temp_rotationX,"%.2f",datasd_sensors.x_rotation);        // convert rotationX
  	  sprintf(temp_rotationY,"%.2f",datasd_sensors.y_rotation);        // convert rotationY
  	  sprintf(temp_rotationZ,"%.2f",datasd_sensors.z_rotation);        // convert rotationZ
  	  sprintf(temp_altitude,"%.2f",datasd_sensors.height);                // convert altitude
  	  sprintf(temp_time,"%.2f",datasd_sensors.time);                        // convert time



  	  strcat(temp_velocity,temp_tab);
  	  strcat(temp_velocity,temp_accelerationX);
  	  strcat(temp_velocity,temp_tab);
  	  strcat(temp_velocity,temp_accelerationY);
  	  strcat(temp_velocity,temp_tab);
  	  strcat(temp_velocity,temp_accelerationZ);
  	  strcat(temp_velocity,temp_tab);
  	  strcat(temp_velocity,temp_acceleration);
  	  strcat(temp_velocity,temp_tab);

  	  strcat(temp_velocity,temp_rotationX);
  	  strcat(temp_velocity,temp_tab);
  	  strcat(temp_velocity,temp_rotationY);
  	  strcat(temp_velocity,temp_tab);
  	  strcat(temp_velocity,temp_rotationZ);
  	  strcat(temp_velocity,temp_tab);

  	  strcat(temp_velocity,temp_altitude);
  	  strcat(temp_velocity,temp_tab );

  	  strcat(temp_velocity,temp_time );
  	  strcat(temp_velocity,temp_enter);



  	  sd_update_text(temp_velocity,filename);


};

void sd_write_data_gps(struct datasd_gps datasd_gps,char filename[]){

	  char temp_UTCtimehours[200];
	  char temp_UTCtimeminutes[20];
	  char temp_UTCtimeseconds[20];
	  char temp_latitude[20];
	  char temp_longtitude[20];
	  char temp_satellites[20];
	  char temp_HDOP[20];
	  char temp_altitude[20];
	  char temp_sea_level[20];
	  char temp_flight_time[20];
	  char temp_tab[]="\t";
	  char temp_updown[]=":";
	  char temp_enter[]="\n";
	  char temp_zero[]="0";

	  int hours;
	  int minutes;
	  int seconds;

	  hours = datasd_gps.current_time_UTC / 10000;
	  minutes = datasd_gps.current_time_UTC / 100;
	  minutes = minutes % 100;
	  seconds = ((int)datasd_gps.current_time_UTC) % 100;


	  sprintf(temp_UTCtimehours,"%d",hours);               	 // convert float to string
  	  sprintf(temp_UTCtimeminutes,"%d",minutes);
  	  sprintf(temp_UTCtimeseconds,"%d",seconds);
  	  sprintf(temp_latitude,"%.6f",datasd_gps.lat);
  	  sprintf(temp_longtitude,"%.6f",datasd_gps.lon);
  	  sprintf(temp_satellites,"%d",(int)datasd_gps.satellites);
  	  sprintf(temp_HDOP,"%.1f",datasd_gps.HDOP);
  	  sprintf(temp_altitude,"%.1f",datasd_gps.altitude);
  	  sprintf(temp_sea_level,"%.1f",datasd_gps.sea_level);
  	  sprintf(temp_flight_time,"%.2f",datasd_gps.flight_time);

	  strcat(temp_UTCtimehours,temp_updown );
	  if(minutes<10){
		  strcat(temp_UTCtimehours,temp_zero);
	  }
	  strcat(temp_UTCtimehours,temp_UTCtimeminutes );
	  strcat(temp_UTCtimehours,temp_updown );
	  if(seconds<10){
		  strcat(temp_UTCtimehours,temp_zero);
	  }
	  strcat(temp_UTCtimehours,temp_UTCtimeseconds );
	  strcat(temp_UTCtimehours,temp_tab );

  	  strcat(temp_UTCtimehours,temp_latitude );
  	  strcat(temp_UTCtimehours,temp_tab );

  	  strcat(temp_UTCtimehours,temp_longtitude );
  	  strcat(temp_UTCtimehours,temp_tab );

  	  strcat(temp_UTCtimehours,temp_satellites );
  	  strcat(temp_UTCtimehours,temp_tab );

  	  strcat(temp_UTCtimehours,temp_HDOP );
  	  strcat(temp_UTCtimehours,temp_tab );

  	 strcat(temp_UTCtimehours,temp_altitude );
  	 strcat(temp_UTCtimehours,temp_tab );

  	 strcat(temp_UTCtimehours,temp_sea_level );
  	 strcat(temp_UTCtimehours,temp_tab );

	 strcat(temp_UTCtimehours, temp_flight_time);
	 strcat(temp_UTCtimehours,temp_enter );

	 sd_update_text(temp_UTCtimehours,filename);


};



void sd_write_general_info(float thrust_end_time,float apogee , float apogee_time, float drogue_time, float main_deploy_time ,float flight_end_time){

	thrust_end_time = thrust_end_time / 1000;
	apogee_time = apogee_time /1000;
	drogue_time = drogue_time / 1000 ;
	main_deploy_time = main_deploy_time / 1000;
	flight_end_time = flight_end_time /1000;

	char temp_four_enter[200]="\n\n\n";
	char temp_thrust[]="Thrust phase ended,Time:";
	char temp_thrust_time[20];
	char temp_apogee[]="Apogee:";
	char temp_apogee_height[20];
	char temp_apogee2[]="m ,Apogee Time: ";
	char temp_apogee_time[20];
	char temp_drogue[]="Time drogue parachute opened: ";
	char temp_drogue_time[20];
	char temp_main[]="Time main parachute opened: ";
	char temp_main_time[20];
	char temp_land[]="Rocket Landed, Time:";
	char temp_land_time[20];
	char temp_enter[]="s\n";




	sprintf(temp_thrust_time,"%.2f",thrust_end_time);
	sprintf(temp_apogee_height,"%.2f",apogee);
	sprintf(temp_apogee_time,"%.2f",apogee_time);
	sprintf(temp_drogue_time,"%.2f",drogue_time);
	sprintf(temp_main_time,"%.2f",main_deploy_time);
	sprintf(temp_land_time,"%.2f",flight_end_time);

	strcat(temp_four_enter,temp_thrust);            //connect thrust string
	strcat(temp_four_enter,temp_thrust_time);
	strcat(temp_four_enter,temp_enter);

	strcat(temp_four_enter,temp_apogee);            //connect apogee string
	strcat(temp_four_enter,temp_apogee_height);
	strcat(temp_four_enter,temp_apogee2);
	strcat(temp_four_enter,temp_apogee_time);
	strcat(temp_four_enter,temp_enter);

	strcat(temp_four_enter,temp_drogue);
	strcat(temp_four_enter,temp_drogue_time);         //connect drogue string
	strcat(temp_four_enter,temp_enter);

	strcat(temp_four_enter,temp_main);             //connect main parachute string
	strcat(temp_four_enter,temp_main_time);
	strcat(temp_four_enter,temp_enter);

	strcat(temp_four_enter,temp_land);             //connect land string
	strcat(temp_four_enter,temp_land_time);
	strcat(temp_four_enter,temp_enter);

	sd_update_text(temp_four_enter,"general.txt");
};

void sd_create_text_sensors(char filename[]){
	sd_update_text("Velocity(m/s)	AccelerationX	AccelerationY	AccelerationZ	Acceleration(m/s^2)	RotationX	RotationY	RotationZ	Altitude(m)	FlightTime(s)\n",filename);
};

void sd_create_text_gps(char filename[]){
	sd_update_text("UTC_TIME	Latitude	Longtitude	Satellites	HDOP	Altitude(m)	SeaLevel(m)	FlightTime(s)\n",filename);
};


int bufsize(char *buf)
{
	int i=0;
	while (*buf++ !='\0') i++;
	return i;
}

/*clear buffer*/
void bufclear (void)
{
	for (int i=0;i<100;i++)
	{
		buffer[i]='\0';
	}
}


void sd_update_text(char s[],char filename[]){
	 /*********************UPDATING an existing file ***************************/
	//mount SD
	//	fres = f_mount(&fs, "", 0);
	// FA_OPEN_APPEND opens file if it exists and if not then creates it,
	// the pointer is set at the end of the file for appending
	// example of filename is "flight.txt"
	fres = f_open(&fil, filename, FA_OPEN_APPEND | FA_WRITE | FA_READ);
	//write in the file
	f_puts(s, &fil);
	//closes the file
	fres = f_close(&fil);
	//unmount SD
	//	f_mount(NULL, "", 1);
};

uint32_t sd_get_free_space(){
	//mount SD
	//fres = f_mount(&fs, "", 0);
	//gets free space
	fres = f_getfree("", &fre_clust, &pfs);
	//returns free space
	return freeSpace = (uint32_t) (fre_clust * pfs->csize * 0.5);

}
