/*
 * memories.h
 *
 *  Created on: 26 Ιουλ 2023
 *      Author: Vaggelis
 */

#ifndef INC_MEMORIES_H_
#define INC_MEMORIES_H_

#define FLASH_TOTAL_SPACE 4194303 //in bytes
#define NUMBER_OF_GARBAGE 3
#define NUMBER_OF_SPACE 100000
#define GPS_DATA_START_ADDRESS 600000

uint32_t flash_address_sensors ;
uint32_t flash_address_gps;

int flash_free_space_check();
void flash_clear();

void write_data_sensors(struct datasd_sensors datasd_sensors);
void write_data_gps(struct datasd_gps datasd_gps);

void flash_read_and_write_to_sd_sensors(char filename[]);
void flash_read_and_write_to_sd_gps(char filename[]);

uint16_t convert_data_for_flash(float data , int multiplication_factor);
float convert_data_for_sd(uint16_t  data, int division_factor);



#endif /* INC_MEMORIES_H_ */
