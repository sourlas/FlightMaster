/*
 * mpu6500.h
 *
 *  Created on: Oct 20, 2019
 *      Author: ASAT
 * Selected below are the reccomended settings for the +-16g and +-2000dps scale
 */

#ifndef MPU6500_H_
#define MPU6500_H_
#include "stm32l4xx_hal.h"
#define config_address 0x1A
#define accel_config_address 0x1C
#define accel_config2_address 0x1D
#define gyro_config_address 0x1B
#define accel_xout_msb_address 0x3B
#define accel_yout_msb_address 0x3D
#define accel_zout_msb_address 0x3F
#define gyro_zout_msb_address 0x47
#define gyro_yout_msb_address 0x45
#define gyro_xout_msb_address 0x43

struct MPU6500{
	SPI_HandleTypeDef *hspi;
	GPIO_TypeDef *gpio_port;
	uint16_t gpio_pin;
};

/*
 * configuration bits of accel_config_address, uncomment according to your project
 * */
#define XA_ST 0b00000000	//disable x self test
//#define XA_ST 0b10000000 //enable x self test
#define YA_ST 0b00000000	//disable y self test
//#define YA_ST 0b01000000 	//enable y self test
#define ZA_ST 0b00000000	//disable z self test
//#define ZA_ST 0b00100000	//enable z self test
//#define ACCEL_FS_SEL 0b00000000	//+-2g
//#define ACCEL_FS_SEL 0b00001000	//+-4g
//#define ACCEL_FS_SEL 0b00010000	//+-8g
#define ACCEL_FS_SEL 0b00011000		//+-16g

/*
 * Please refer to the following document for information
 * MPU-6500 register Map and Descriptions section 4.8 revision 2.1
 */
#define	accel_config2_value 0b00001000	//disable dlp filter
//#define	accel_config2_value 0b00000000
//#define	accel_config2_value 0b00000001
//#define	accel_config2_value 0b00000010
//#define	accel_config2_value 0b00000011
//#define	accel_config2_value 0b00000100
//#define	accel_config2_value 0b00000101
//#define	accel_config2_value 0b00000110
//#define	accel_config2_value 0b00000111

/*
 * Please refer to the following document for information
 * MPU-6500 register Map and Descriptions section 4.5 revision 2.1
 */

/*
 * configuration bits of gyro_config_address, uncomment according to your project
 * */
#define XG_ST 0b00000000	//disable x self test
//#define XG_ST 0b10000000 //enable x self test
#define YG_ST 0b00000000	//disable y self test
//#define YG_ST 0b01000000 	//enable y self test
#define ZG_ST 0b00000000	//disable z self test
//#define ZG_ST 0b00100000	//enable z self test
//#define GYRO_FS_SEL 0b00000000	//+-250dps
//#define GYRO_FS_SEL 0b00001000	//+-500dps
//#define GYRO_FS_SEL 0b00010000	//+-1000dps
#define GYRO_FS_SEL 0b00011000	//+-2000dps


#define	FIFO_MODE 0b00000000	//when the fifo is full aditional writes will replace the oldest data
//#define	FIFO_MODE 0b01000000 //when the fifo is full aditional writes will not be written to fifo
#define	EXT_SYNC_SET 0b00000000	//fsync disabled
//#define	EXT_SYNC_SET 0b00001000
//#define	EXT_SYNC_SET 0b00010000
//#define	EXT_SYNC_SET 0b00011000
//#define	EXT_SYNC_SET 0b00100000
//#define	EXT_SYNC_SET 0b00101000
//#define	EXT_SYNC_SET 0b00110000
//#define	EXT_SYNC_SET 0b00111000
#define	DLPF_CFG 0b00000000	//DLPF won't be used
//#define	DLPF_CFG 0b00000011 //DLPF can be used

//Accelerometer
uint8_t registerRead_Accel(uint8_t address, struct MPU6500 sensor);
int16_t read_2_registersAccel(uint8_t address, struct MPU6500 sensor);
void registerWrite_Accel(uint8_t address, uint8_t msg, struct MPU6500 sensor);
float get_z_accel(struct MPU6500 sensor);
float get_y_accel(struct MPU6500 sensor);
float get_x_accel(struct MPU6500 sensor);
float overall_acceleration(struct MPU6500 sensor);
//Gyroscope
uint8_t registerRead_Gyro(uint8_t address, struct MPU6500 sensor);
int16_t read_2_registersGyro(uint8_t address, struct MPU6500 sensor);
void registerWrite_Gyro(uint8_t address, uint8_t msg, struct MPU6500 sensor);
float get_z_rotation(struct MPU6500 sensor);
float get_y_rotation(struct MPU6500 sensor);
float get_x_rotation(struct MPU6500 sensor);

void mpu6500_sensor_Init(struct MPU6500 *sensor, SPI_HandleTypeDef *hspi, GPIO_TypeDef *port, uint16_t pin);


#endif /* MPU6500_H_ */
