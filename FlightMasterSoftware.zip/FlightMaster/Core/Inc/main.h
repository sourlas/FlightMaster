/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
struct dataflash_sensors{
	uint16_t x_acceleration;
	uint16_t y_acceleration;
	uint16_t z_acceleration;
	uint16_t x_rotation;
	uint16_t y_rotation;
	uint16_t z_rotation;
	uint16_t height;
	uint16_t velocity;
	uint32_t time;
};

struct datasd_sensors{
	float x_acceleration;
	float y_acceleration;
	float z_acceleration;
	float x_rotation;
	float y_rotation;
	float z_rotation;
	float height;
	float velocity;
	float time;
};

struct datasd_gps{
	float current_time_UTC;
	float lat;
	float lon;
	float satellites;
	float HDOP;
	float altitude;
	float sea_level;
	float flight_time;
};

struct dataflash_gps{
	uint32_t current_time_UTC;
	uint32_t lat;
	uint32_t lon;
	uint8_t  satellites;
	uint16_t HDOP;
	uint16_t altitude;
	uint16_t sea_level;
	uint32_t flight_time;

};

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define DROGUE_CHECK_Pin GPIO_PIN_13
#define DROGUE_CHECK_GPIO_Port GPIOC
#define DROGUE_CONTINUITY_Pin GPIO_PIN_14
#define DROGUE_CONTINUITY_GPIO_Port GPIOC
#define DROGUE_Pin GPIO_PIN_15
#define DROGUE_GPIO_Port GPIOC
#define MAIN_Pin GPIO_PIN_0
#define MAIN_GPIO_Port GPIOH
#define MAIN_CHECK_Pin GPIO_PIN_1
#define MAIN_CHECK_GPIO_Port GPIOH
#define MAIN_CONTINUITY_Pin GPIO_PIN_0
#define MAIN_CONTINUITY_GPIO_Port GPIOA
#define BUZZER_Pin GPIO_PIN_1
#define BUZZER_GPIO_Port GPIOA
#define SWITCH_2_Pin GPIO_PIN_4
#define SWITCH_2_GPIO_Port GPIOA
#define SWITCH_1_Pin GPIO_PIN_0
#define SWITCH_1_GPIO_Port GPIOB
#define SD_CS_Pin GPIO_PIN_1
#define SD_CS_GPIO_Port GPIOB
#define FLASH_HOLD_Pin GPIO_PIN_2
#define FLASH_HOLD_GPIO_Port GPIOB
#define flash_CS_Pin GPIO_PIN_12
#define flash_CS_GPIO_Port GPIOB
#define FLASH_WP_Pin GPIO_PIN_8
#define FLASH_WP_GPIO_Port GPIOA
#define RF_SEL_Pin GPIO_PIN_9
#define RF_SEL_GPIO_Port GPIOA
#define RF_IRQ_Pin GPIO_PIN_10
#define RF_IRQ_GPIO_Port GPIOA
#define RF_SWITCH_Pin GPIO_PIN_11
#define RF_SWITCH_GPIO_Port GPIOA
#define GPS_SWITCH_Pin GPIO_PIN_12
#define GPS_SWITCH_GPIO_Port GPIOA
#define CS_ACCEL_Pin GPIO_PIN_15
#define CS_ACCEL_GPIO_Port GPIOA
#define ACCEL_INT_Pin GPIO_PIN_6
#define ACCEL_INT_GPIO_Port GPIOB
#define CS_BAR_Pin GPIO_PIN_7
#define CS_BAR_GPIO_Port GPIOB
#define LED_RED_Pin GPIO_PIN_8
#define LED_RED_GPIO_Port GPIOB
#define LED_GREEN_Pin GPIO_PIN_9
#define LED_GREEN_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
