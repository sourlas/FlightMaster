/*
 * SD_Functions.h
 *
 *  Created on: Mar 22, 2023
 *      Author: Vaggelis
 */




#ifndef SD_FUNCTIONS_H_
#define SD_FUNCTIONS_H_


SPI_HandleTypeDef hspi1;
FATFS fs;
FATFS *pfs;
FIL fil;
FRESULT fres;
DWORD fre_clust;
uint32_t totalSpace , freeSpace;
char buffer[100];


void sd_write_data_sensors(struct datasd_sensors datasd_sensors,char filename[]);
void sd_write_data_gps(struct datasd_gps datasd_gps,char filename[]);

void sd_create_text_sensors(char filename[]);
void sd_create_text_gps(char filename[]);

void sd_update_text(char s[],char filename[]);

void sd_write_general_info(float thrust_end_time,float apogee , float apogee_time,float drogue_time, float main_deploy_time ,float flight_end_time);

int bufsize(char *buf);
void bufclear(void) ;

uint32_t sd_get_free_space();

#endif /* SD_FUNCTIONS_H_ */
