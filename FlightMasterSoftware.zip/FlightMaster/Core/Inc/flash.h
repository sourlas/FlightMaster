/*
 * flash.h
 *
 *  Created on: May 22, 2023
 *      Author: Vaggelis
 */

#ifndef FLASH_H_
#define FLASH_H_

void writeEnable(SPI_HandleTypeDef hspi1);
void writeDisable(SPI_HandleTypeDef hspi1);
void sectorErase(SPI_HandleTypeDef hspi1, uint8_t *address);
uint8_t readStatusRegister1(SPI_HandleTypeDef hspi1);
uint8_t readStatusRegister2(SPI_HandleTypeDef hspi1);
uint8_t readStatusRegister3(SPI_HandleTypeDef hspi1);
uint8_t getBusy(SPI_HandleTypeDef hspi1);
void pageProgram(SPI_HandleTypeDef hspi1,uint8_t *writeData, uint16_t size, uint8_t *address);
void chipErase(SPI_HandleTypeDef hspi1);
void readData(SPI_HandleTypeDef hspi1, uint8_t *address,uint16_t size,uint8_t *read);
uint8_t readID(SPI_HandleTypeDef hspi1);
#endif /* FLASH_H_ */
